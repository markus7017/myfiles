/*
 * Copyright (c) 2010-2026 Contributors to the openHAB project
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0
 *
 * SPDX-License-Identifier: EPL-2.0
 */
package org.openhab.binding.shelly.internal.handler;

import static org.openhab.binding.shelly.internal.ShellyBindingConstants.*;
import static org.openhab.binding.shelly.internal.ShellyDevices.*;
import static org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.*;
import static org.openhab.binding.shelly.internal.handler.ShellyComponents.*;
import static org.openhab.binding.shelly.internal.util.ShellyUtils.*;
import static org.openhab.core.thing.Thing.*;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import org.eclipse.jdt.annotation.NonNullByDefault;
import org.eclipse.jdt.annotation.Nullable;
import org.eclipse.jetty.client.HttpClient;
import org.eclipse.jetty.websocket.client.WebSocketClient;
import org.openhab.binding.shelly.internal.api.ShellyApiException;
import org.openhab.binding.shelly.internal.api.ShellyApiInterface;
import org.openhab.binding.shelly.internal.api.ShellyApiResult;
import org.openhab.binding.shelly.internal.api.ShellyDeviceProfile;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellyFavPos;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellyInputState;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellyOtaCheckResult;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellySettingsDevice;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellySettingsStatus;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellyThermnostat;
import org.openhab.binding.shelly.internal.api1.Shelly1CoapHandler;
import org.openhab.binding.shelly.internal.api1.Shelly1CoapJSonDTO;
import org.openhab.binding.shelly.internal.api1.Shelly1CoapServer;
import org.openhab.binding.shelly.internal.api1.Shelly1HttpApi;
import org.openhab.binding.shelly.internal.api2.Shelly2ApiJsonDTO;
import org.openhab.binding.shelly.internal.api2.Shelly2ApiJsonDTO.Shelly2APClientList.Shelly2APClient;
import org.openhab.binding.shelly.internal.api2.Shelly2ApiRpc;
import org.openhab.binding.shelly.internal.api2.ShellyBluApi;
import org.openhab.binding.shelly.internal.config.ShellyApiConfiguration;
import org.openhab.binding.shelly.internal.config.ShellyBindingRuntimeConfig;
import org.openhab.binding.shelly.internal.config.ShellyThingConfiguration;
import org.openhab.binding.shelly.internal.discovery.ShellyBasicDiscoveryService;
import org.openhab.binding.shelly.internal.discovery.ShellyThingCreator;
import org.openhab.binding.shelly.internal.handler.ShellyDeviceStats.ShellyDeviceAlarm;
import org.openhab.binding.shelly.internal.provider.ShellyChannelDefinitions;
import org.openhab.binding.shelly.internal.provider.ShellyTranslationProvider;
import org.openhab.binding.shelly.internal.util.ShellyChannelCache;
import org.openhab.binding.shelly.internal.util.ShellyVersionDTO;
import org.openhab.core.config.discovery.DiscoveryResult;
import org.openhab.core.library.types.DecimalType;
import org.openhab.core.library.types.OnOffType;
import org.openhab.core.library.types.OpenClosedType;
import org.openhab.core.library.types.QuantityType;
import org.openhab.core.thing.Channel;
import org.openhab.core.thing.ChannelUID;
import org.openhab.core.thing.Thing;
import org.openhab.core.thing.ThingStatus;
import org.openhab.core.thing.ThingStatusDetail;
import org.openhab.core.thing.ThingTypeUID;
import org.openhab.core.thing.binding.BaseThingHandler;
import org.openhab.core.thing.binding.builder.ThingBuilder;
import org.openhab.core.thing.type.ChannelTypeUID;
import org.openhab.core.types.Command;
import org.openhab.core.types.RefreshType;
import org.openhab.core.types.State;
import org.openhab.core.types.StateOption;
import org.openhab.core.types.UnDefType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The {@link ShellyBaseHandler} is responsible for handling commands, which are
 * sent to one of the channels.
 *
 * @author Markus Michels - Initial contribution
 */
@NonNullByDefault
public abstract class ShellyBaseHandler extends BaseThingHandler
        implements ShellyThingInterface, ShellyDeviceListener, ShellyManagerInterface {

    protected final Logger logger = LoggerFactory.getLogger(ShellyBaseHandler.class);
    protected final ShellyChannelDefinitions channelDefinitions;

    public String thingName = "";
    public String thingType = "";

    protected final ShellyApiInterface api;
    private final HttpClient httpClient;
    private final ShellyThingTable thingTable;

    private final ShellyBindingRuntimeConfig bindingConfig;
    protected volatile ShellyThingConfiguration config;
    protected final ShellyApiConfiguration apiConfig;
    private final ShellyTranslationProvider messages;
    private final ShellyChannelCache cache;
    private static final long DEPRECATED_CHANNEL_WARNING_INTERVAL_MS = TimeUnit.DAYS.toMillis(1);

    private final Map<String, Long> deprecatedChannelWarnings = new ConcurrentHashMap<>();
    private final int cacheCount = UPDATE_SETTINGS_INTERVAL_SECONDS / UPDATE_STATUS_INTERVAL_SECONDS;

    private volatile @Nullable Shelly1CoapHandler coap;

    private final boolean gen2;
    private final boolean blu;

    // Thing status
    protected volatile boolean autoCoIoT;
    protected volatile ShellyDeviceProfile profile;
    private volatile ShellyDeviceStats stats = new ShellyDeviceStats();
    private volatile boolean channelsCreated = false;
    private volatile boolean stopping = false;
    private int vibrationFilter = 0;
    private String lastWakeupReason = "";

    // Scheduler
    private volatile double watchdog = now();
    protected int scheduledUpdates = 0;
    private int skipCount = UPDATE_SKIP_COUNT;
    private int skipUpdate = 0;
    private boolean refreshSettings;
    private @Nullable ScheduledFuture<?> statusJob;
    private @Nullable ScheduledFuture<?> initJob;

    /**
     * Constructor
     *
     * @param thing The Thing object
     * @param translationProvider
     * @param bindingConfig The binding configuration (beside thing
     *            configuration)
     * @param thingTable
     * @param coapServer coap server instance
     * @param httpClient from httpService
     */
    public ShellyBaseHandler(final Thing thing, final ShellyTranslationProvider translationProvider,
            final ShellyBindingRuntimeConfig bindingConfig, ShellyThingTable thingTable,
            final Shelly1CoapServer coapServer, final HttpClient httpClient, WebSocketClient webSocketClient) {
        super(thing);

        this.thingTable = thingTable;
        this.thingName = getString(thing.getLabel());
        this.bindingConfig = bindingConfig;
        this.messages = translationProvider;
        this.cache = new ShellyChannelCache(this);
        this.channelDefinitions = new ShellyChannelDefinitions(messages);
        this.httpClient = httpClient;

        // Create thing handler depending on device generation
        ThingTypeUID thingTypeUID = thing.getThingTypeUID();
        profile = new ShellyDeviceProfile(thingTypeUID);
        blu = ShellyDeviceProfile.isBluSeries(thingTypeUID);
        gen2 = ShellyDeviceProfile.isGeneration2(thingTypeUID);

        // Create API config without DNS resolution (framework thread — must not block).
        // buildApiConfig() is called again from initializeThingConfig() on the scheduler
        // thread where blocking hostname resolution is safe.
        config = getConfigAs(ShellyThingConfiguration.class);
        apiConfig = new ShellyApiConfiguration(config, bindingConfig,
                getString(getThing().getProperties().get(PROPERTY_SERVICE_NAME)), gen2, false);

        // Create API instance
        if (blu) {
            this.api = new ShellyBluApi(thingName, thingTable, this, apiConfig, webSocketClient, scheduler);
        } else if (gen2) {
            this.api = new Shelly2ApiRpc(thingName, thingTable, this, apiConfig, webSocketClient, scheduler);
        } else {
            this.api = new Shelly1HttpApi(thingName, apiConfig, this);
        }

        coap = apiConfig.getEnableCoIOT() ? new Shelly1CoapHandler(this, thingName, apiConfig, coapServer) : null;
    }

    private void updateApiConfig() {
        Map<String, String> properties = getThing().getProperties();
        synchronized (apiConfig) {
            apiConfig.setRealm(getString(properties.get(PROPERTY_SERVICE_NAME)));
            apiConfig.updateFromThingConfig(config, bindingConfig, gen2);
        }
    }

    @Override
    public boolean checkRepresentation(String key) {
        InetAddress ipAddr;
        return key.equalsIgnoreCase(getUID()) || key.equalsIgnoreCase(apiConfig.getBdAddr())
                || ((ipAddr = apiConfig.getDeviceIpAddress()) != null && key.equalsIgnoreCase(ipAddr.getHostAddress()))
                || key.equalsIgnoreCase(apiConfig.getDeviceHostAddress()) || key.equalsIgnoreCase(apiConfig.getRealm())
                || key.equalsIgnoreCase(getThingName());
    }

    /**
     * Schedule asynchronous Thing initialization, register thing to event dispatcher
     */
    @Override
    public void initialize() {
        // start background initialization:
        initJob = scheduler.schedule(() -> {
            boolean start = false;
            try {
                if (initializeThingConfig()) {
                    logger.debug("{}: Config: {}", thingName, config);
                    start = initializeThing();
                }
            } catch (ShellyApiException e) {
                start = handleApiException(e);
            } finally {
                // even this initialization failed we start the status update
                // the updateJob will then try to auto-initialize the thing
                // in this case the thing stays in status INITIALIZING
                if (start) {
                    startUpdateJob();
                }
            }
        }, 2, TimeUnit.SECONDS);
    }

    private boolean handleApiException(ShellyApiException e) {
        ShellyApiResult res = e.getApiResult();
        ThingStatusDetail errorCode = ThingStatusDetail.COMMUNICATION_ERROR;
        String status = "";
        boolean retry = true;
        if (e.isJsonError()) { // invalid JSON format
            logger.debug("{}: Unable to parse API response: {}; json={}", thingName, res.getUrl(), res.response, e);
            status = "offline.status-error-unexpected-error";
            errorCode = ThingStatusDetail.CONFIGURATION_ERROR;
            retry = false;
        } else if (res.isHttpAccessUnauthorized()) {
            status = "offline.conf-error-access-denied";
            errorCode = ThingStatusDetail.CONFIGURATION_ERROR;
            retry = false;
        } else if (isWatchdogExpired()) {
            status = profile.isBlu ? "offline.status-error-blu-timeout" : "offline.status-error-watchdog";
        } else if (res.httpCode >= 400) {
            logger.debug("{}: Unexpected API result: {}/{}", thingName, res.httpCode, res.httpReason, e);
            status = "offline.status-error-unexpected-api-result";
            retry = false;
        } else if (profile.alwaysOn && (e.isConnectionError() || res.isHttpTimeout())) {
            status = "offline.status-error-connect";
        }

        if (!status.isEmpty()) {
            setThingOfflineAndDisconnect(errorCode, status, e.toString());
        } else {
            logger.debug("{}: Unable to initialize: {}, retrying later", thingName, e.toString());
        }

        if (!retry) {
            api.close();
        }

        return retry;
    }

    @Override
    public ShellyThingConfiguration getThingConfig() {
        return config;
    }

    @Override
    public ShellyApiConfiguration getApiConfig() {
        return apiConfig;
    }

    @Override
    public HttpClient getHttpClient() {
        return httpClient;
    }

    @Override
    public void startScan() {
        if (api.isInitialized()) {
            api.startScan();
        }

        checkRangeExtender(profile);
    }

    /**
     * This routine is called every time the Thing configuration has been changed
     */
    @Override
    public void handleConfigurationUpdate(Map<String, Object> configurationParameters) {
        super.handleConfigurationUpdate(configurationParameters);
        logger.debug("{}: Thing config was updated, re-initialize", thingName);
        Shelly1CoapHandler coap = this.coap;
        if (coap != null) {
            coap.stop();
        }
        config = getConfigAs(ShellyThingConfiguration.class);
        updateApiConfig();
        stopping = false;
        reinitializeThing();// force re-initialization
    }

    /**
     * Initialize Thing: Initialize API access, get settings and initialize Device Profile
     * If the device is password protected and the credentials are missing or don't match the API access will throw an
     * Exception. In this case the thing type will be changed to shelly-unknown. The user has the option to edit the
     * thing config and set the correct credentials. The thing type will be changed to the requested one if the
     * credentials are correct and the API access is initialized successful.
     *
     * @throws ShellyApiException e.g. http returned non-ok response, check e.getMessage() for details.
     */
    public boolean initializeThing() throws ShellyApiException {
        // Init from thing type to have a basic profile, gets updated when device info is received from API
        refreshSettings = false;
        lastWakeupReason = "";
        cache.setThingName(thingName);
        cache.clear();
        resetStats();

        profile.initFromThingType(thing.getThingTypeUID());
        if (logger.isDebugEnabled()) {
            InetSocketAddress socketAddr = apiConfig.getDeviceSocketAddress();
            InetAddress ipAddr = socketAddr == null ? null : socketAddr.getAddress();
            String ipAddrStr = ipAddr == null ? "none" : ipAddr.getHostAddress();
            int port = socketAddr == null ? 0 : socketAddr.getPort();
            String bdAdr = apiConfig.getBdAddr();
            bdAdr = bdAdr == null ? "none" : bdAdr.toLowerCase(Locale.ROOT);
            logger.debug(
                    "{}: Start initializing for thing {}, type {}, Device IP address {}, Device port {}, Bluetooth device address {}, Gen2: {}, isBlu: {}, alwaysOn: {}, hasBattery: {}, CoIoT: {}",
                    thingName, getThing().getLabel(), thingType, ipAddrStr, port == 0 ? "none" : port, bdAdr, gen2,
                    profile.isBlu, profile.alwaysOn, profile.hasBattery, apiConfig.getEnableCoIOT());
        }

        if (profile.alwaysOn || !profile.isInitialized() && !isThingOnline()) {
            ThingStatusDetail detail = getThingStatusDetail();
            if (detail != ThingStatusDetail.DUTY_CYCLE) {
                updateStatus(ThingStatus.ONLINE, ThingStatusDetail.CONFIGURATION_PENDING,
                        messages.get("status.config_pending"));
            }
        }

        // Gen 1 only: Setup CoAP listener so we get the CoAP message, which triggers initialization even the thing
        // could not be fully initialized here. In this case the CoAP messages triggers auto-initialization (like the
        // Action URL does when enabled)
        Shelly1CoapHandler coap = this.coap;
        if (coap != null && apiConfig.getEnableCoIOT() && !profile.alwaysOn) {
            coap.start();
        }

        // Initialize API access, exceptions will be catched by initialize()
        api.initialize();
        ShellySettingsDevice device = profile.device = api.getDeviceInfo();
        if (getBool(device.auth) && apiConfig.getPassword().isBlank()) {
            setThingOfflineAndDisconnect(ThingStatusDetail.CONFIGURATION_ERROR, "offline.conf-error-no-credentials");
            return false;
        }
        if (apiConfig.getRealm().isEmpty()) {
            apiConfig.setRealm(getString(device.hostname).toLowerCase(Locale.ROOT));
        }

        ShellyDeviceProfile tmpPrf = api.getDeviceProfile(thing.getThingTypeUID(), profile.device);
        tmpPrf.initFromThingType(thing.getThingTypeUID());
        String mode = getString(tmpPrf.device.mode);
        if (this.getThing().getThingTypeUID().equals(THING_TYPE_SHELLYPROTECTED)) {
            changeThingType(thingName, mode);
            return false; // force re-initialization
        }
        // Validate device mode
        String reqMode = thingType.contains("-") ? substringAfter(thingType, "-") : "";
        if (!reqMode.isEmpty() && !mode.equals(reqMode)) {
            setThingOfflineAndDisconnect(ThingStatusDetail.CONFIGURATION_ERROR, "offline.conf-error-wrong-mode", mode,
                    reqMode);
            return false;
        }
        if (!getString(tmpPrf.device.coiot).isEmpty()) {
            // New Shelly devices might use a different endpoint for the CoAP listener
            tmpPrf.coiotEndpoint = tmpPrf.device.coiot;
        }
        if (tmpPrf.settings.sleepMode != null && !tmpPrf.isTRV) {
            // Sensor, usually 12h, H&T in USB mode 10min
            tmpPrf.updatePeriod = "m".equalsIgnoreCase(getString(tmpPrf.settings.sleepMode.unit))
                    ? tmpPrf.settings.sleepMode.period * 60 // minutes
                    : tmpPrf.settings.sleepMode.period * 3600; // hours
            if (tmpPrf.isSmoke) {
                tmpPrf.updatePeriod += 1800; // for smoke sensor give 30min extra
            } else {
                tmpPrf.updatePeriod += 60; // give 1min extra
            }
        } else if (tmpPrf.settings.coiot != null && tmpPrf.settings.coiot.updatePeriod != null) {
            // Derive from CoAP update interval, usually 2*15+10s=40sec -> 70sec
            tmpPrf.updatePeriod = 2 * //
                    Math.max(UPDATE_SETTINGS_INTERVAL_SECONDS, getInteger(tmpPrf.settings.coiot.updatePeriod)) + 10;
        } else {
            tmpPrf.updatePeriod = 2 * UPDATE_SETTINGS_INTERVAL_SECONDS + 10;
        }

        tmpPrf.status = api.getStatus(); // update thing properties
        tmpPrf.updateFromStatus(tmpPrf.status);
        addStateOptions(tmpPrf);

        // update thing properties
        updateProperties(tmpPrf, tmpPrf.status);
        checkVersion(tmpPrf, tmpPrf.status);

        // Check for Range Extender mode, add secondary device to Inbox
        checkRangeExtender(tmpPrf);

        startCoap(tmpPrf);
        if (!gen2 && !blu) {
            // Always call setActionURLs() for Gen1: when CoIoT is active (enableCoIOT=true),
            // setEventUrls() internally forces all flags to false so previously registered
            // action URLs are cleared from the device.
            api.setActionURLs();
        }

        // All initialization done, so keep the profile and set Thing to ONLINE
        profile = tmpPrf;
        ShellyChannelMigration.migrateChannels(this);
        showThingConfig(profile);

        // Push the full channel state now rather than waiting for the next background poll,
        // so a disable/enable cycle doesn't show stale/default channel values in the meantime.
        updateAllChannels(profile.status);
        postEvent(ALARM_TYPE_NONE, false);

        logger.debug("{}: Thing successfully initialized.", thingName);
        updateProperties(profile, profile.status);
        // channels were already pushed synchronously above; an extra warm-up poll here
        // would race with that fresh read and can transiently show a stale/wrong value
        setThingOnline(false);
        return true; // success
    }

    /**
     * Handle Channel Commands
     */
    @Override
    public void handleCommand(ChannelUID channelUID, Command command) {
        // Capture the channel value before any command handling runs an optimistic update, so a
        // failed API call can restore the true previous state rather than the already-overwritten one.
        String group = getString(channelUID.getGroupId());
        String channel = getString(channelUID.getIdWithoutGroup());
        State oldValue = getChannelValue(group, channel);
        try {
            if (command instanceof RefreshType) {
                String channelId = channelUID.getId();
                State value = cache.getValue(channelId);
                if (value != UnDefType.NULL) {
                    updateState(channelId, value);
                }
                return;
            }

            if (!profile.isInitialized()) {
                logger.debug("{}: {}", thingName, messages.get("command.init", command));
                initializeThing();
            } else {
                profile = getProfile(false);
            }

            boolean update = false;
            switch (channelUID.getIdWithoutGroup()) {
                case CHANNEL_SENSE_KEY: // Shelly Sense: Send Key
                    logger.debug("{}: Send key {}", thingName, command);
                    api.sendIRKey(command.toString());
                    update = true;
                    break;

                case CHANNEL_LED_STATUS_DISABLE:
                    logger.debug("{}: Set STATUS LED disabled to {}", thingName, command);
                    api.setLedStatus(SHELLY_LED_STATUS_DISABLE, command == OnOffType.ON);
                    break;
                case CHANNEL_LED_POWER_DISABLE:
                    logger.debug("{}: Set POWER LED disabled to {}", thingName, command);
                    api.setLedStatus(SHELLY_LED_POWER_DISABLE, command == OnOffType.ON);
                    break;

                case CHANNEL_SENSOR_SLEEPTIME:
                    logger.debug("{}: Set sensor sleep time to {}", thingName, command);
                    int value = getNumber(command).intValue();
                    value = value > 0 ? Math.max(SHELLY_MOTION_SLEEPTIME_OFFSET, value - SHELLY_MOTION_SLEEPTIME_OFFSET)
                            : 0;
                    api.setSleepTime(value);
                    break;
                case CHANNEL_CONTROL_SCHEDULE:
                    if (profile.isTRV) {
                        logger.debug("{}: {} Valve schedule/profile", thingName,
                                command == OnOffType.ON ? "Enable" : "Disable");
                        api.setValveProfile(0,
                                command == OnOffType.OFF ? 0 : profile.status.thermostats.get(0).profile);
                    }
                    break;
                case CHANNEL_CONTROL_PROFILE:
                    logger.debug("{}: Select profile {}", thingName, command);
                    int id = -1;
                    if (command instanceof Number) {
                        id = getNumber(command).intValue();
                    } else {
                        String cmd = command.toString();
                        List<ShellyThermnostat> thermostats = profile.settings.thermostats;
                        if (isDigit(cmd.charAt(0))) {
                            id = Integer.parseInt(cmd);
                        } else if (thermostats != null) {
                            ShellyThermnostat t = thermostats.get(0);
                            for (int i = 0; i < t.profileNames.length; i++) {
                                if (t.profileNames[i].equalsIgnoreCase(cmd)) {
                                    id = i + 1;
                                }
                            }
                        }
                    }
                    if (id < 0 || id > 5) {
                        logger.warn("{}: Invalid profile Id {} requested", thingName, profile);
                        break;
                    }
                    api.setValveProfile(0, id);
                    break;
                case CHANNEL_CONTROL_MODE:
                    logger.debug("{}: Set mode to {}", thingName, command);
                    api.setValveMode(0, SHELLY_TRV_MODE_AUTO.equalsIgnoreCase(command.toString()));
                    break;
                case CHANNEL_CONTROL_SETTEMP:
                    logger.debug("{}: Set temperature to {}", thingName, command);
                    api.setValveTemperature(0, getNumber(command).doubleValue());
                    break;
                case CHANNEL_CONTROL_POSITION:
                    logger.debug("{}: Set position to {}", thingName, command);
                    api.setValvePosition(0, getNumber(command));
                    break;
                case CHANNEL_CONTROL_BCONTROL:
                    logger.debug("{}: Set boost mode to {}", thingName, command);
                    api.startValveBoost(0, command == OnOffType.ON ? -1 : 0);
                    break;
                case CHANNEL_CONTROL_BTIMER:
                    logger.debug("{}: Set boost timer to {}", thingName, command);
                    api.setValveBoostTime(0, getNumber(command).intValue());
                    break;
                case CHANNEL_SENSOR_MUTE:
                    if (profile.isSmoke && ((OnOffType) command) == OnOffType.ON) {
                        logger.debug("{}: Mute Smoke Alarm", thingName);
                        api.muteSmokeAlarm(0);
                        updateChannel(getString(channelUID.getGroupId()), CHANNEL_SENSOR_MUTE, OnOffType.OFF);
                    }
                    break;
                case CHANNEL_EMETER_RESETTOTAL:
                    if (command == OnOffType.ON) {
                        int idx = 0;
                        if (group.startsWith(CHANNEL_GROUP_METER) && group.length() > CHANNEL_GROUP_METER.length()) {
                            idx = Integer.parseInt(substringAfter(group, CHANNEL_GROUP_METER)) - 1;
                        }
                        logger.debug("{}: Reset meter totals for group {}", thingName, group);
                        api.resetMeterTotal(idx);
                        // force: republish OFF even if the cache already holds OFF from a previous reset
                        updateChannel(mkChannelId(group, CHANNEL_EMETER_RESETTOTAL), OnOffType.OFF, true);
                    }
                    break;
                default:
                    update = handleDeviceCommand(channelUID, command);
                    break;
            }

            restartWatchdog();
            if (update && !autoCoIoT && !isUpdateScheduled()) {
                requestUpdates(1, false);
            }
        } catch (ShellyApiException e) {
            if (!handleApiException(e)) {
                return;
            }

            ShellyApiResult res = e.getApiResult();
            if (res.isNotCalibrtated()) {
                logger.warn("{}: {}", thingName, messages.get("roller.calibrating"));
            } else {
                logger.warn("{}: {} - {}", thingName, messages.get("command.failed", command, channelUID),
                        e.toString());
            }

            if (oldValue != UnDefType.NULL) {
                logger.info("{}: Restore channel value to {}", thingName, oldValue);
                updateChannel(group, channel, oldValue);
            }

        } catch (IllegalArgumentException e) {
            logger.debug("{}: {}", thingName, messages.get("command.failed", command, channelUID));
        }
    }

    /**
     * Update device status and channels
     */
    protected void refreshStatus() {
        try {
            if (vibrationFilter > 0) {
                vibrationFilter--;
                logger.debug("{}: Vibration events are absorbed for {} more seconds", thingName,
                        vibrationFilter * UPDATE_STATUS_INTERVAL_SECONDS);
            }

            skipUpdate++;
            if (refreshSettings || (scheduledUpdates > 0) || (skipUpdate % skipCount == 0)) {
                ThingStatus thingStatus = getThing().getStatus();
                if (!profile.isInitialized() || ((thingStatus == ThingStatus.OFFLINE))
                        || (getThingStatusDetail() == ThingStatusDetail.CONFIGURATION_PENDING)) {
                    logger.debug("{}: Status update triggered thing initialization", thingName);
                    initializeThing(); // may fire an exception if initialization failed
                }
                ShellySettingsStatus status = api.getStatus();
                boolean restarted = checkRestarted(status);
                profile = getProfile(refreshSettings || restarted);
                profile.status = status;
                profile.updateFromStatus(status);
                if (restarted) {
                    logger.debug("{}: Device restart #{} detected", thingName, stats.restarts);
                    stats.restarts.incrementAndGet();
                    postEvent(ALARM_TYPE_RESTARTED, true);
                }

                // If status update was successful the thing must be online,
                // but not while firmware update is in progress
                if (getThingStatusDetail() != ThingStatusDetail.FIRMWARE_UPDATING) {
                    setThingOnline();
                }

                // map status to channels
                updateAllChannels(status);
                ShellyChannelMigration.migrateChannels(this);
            }
        } catch (ShellyApiException e) {
            // http call failed: go offline except for battery devices, which might be in
            // sleep mode. Once the next update is successful the device goes back online
            handleApiException(e);
        } finally {
            if (scheduledUpdates > 0) {
                --scheduledUpdates;
                logger.trace("{}: {} more updates requested", thingName, scheduledUpdates);
            } else if ((skipUpdate >= cacheCount) && !cache.isEnabled()) {
                logger.debug("{}: Enabling channel cache ({} updates / {}s)", thingName, skipUpdate,
                        cacheCount * UPDATE_STATUS_INTERVAL_SECONDS);
                cache.enable();
            }
        }
    }

    /**
     * Push the full channel state (relays, meters, inputs, sensors) for the given status.
     * Called both from the initial device init and from every full poll cycle so a Thing
     * disable/enable doesn't leave stale channel values around until the next poll.
     *
     * @return true if any channel was updated
     */
    private boolean updateAllChannels(ShellySettingsStatus status) throws ShellyApiException {
        updateChannel(CHANNEL_GROUP_DEV_STATUS, CHANNEL_DEVST_NAME, getStringType(profile.settings.name));
        boolean updated = this.updateDeviceStatus(status);
        updated |= ShellyComponents.updateDeviceStatus(this, status);
        fillDeviceStatus(status, updated);
        updated |= updateInputs(status);
        updated |= updateMeters(this, status);
        updated |= updateSensors(this, status);

        // All channels must be created after the first cycle
        channelsCreated = true;
        return updated;
    }

    private void checkRangeExtender(ShellyDeviceProfile prf) {
        if (getBool(prf.settings.rangeExtender) && apiConfig.getEnableRangeExtender()
                && prf.status.rangeExtender != null && prf.status.rangeExtender.apClients != null) {
            InetAddress inetAddr = apiConfig.getDeviceIpAddress();
            if (inetAddr == null) {
                if (logger.isDebugEnabled()) {
                    logger.debug("{}: Skipping range extender check because the IP address is unknown", thingName);
                }
            } else {
                String ipAddr = inetAddr.getHostAddress();
                for (Shelly2APClient client : profile.status.rangeExtender.apClients) {
                    String secondaryIp = ipAddr + ":" + client.mport.toString();
                    String name = SERVICE_NAME_SHELLYPLUSRANGE_PREFIX + "-" + client.mac.replaceAll(":", "");
                    DiscoveryResult result = ShellyBasicDiscoveryService.createResult(true, name, secondaryIp,
                            bindingConfig, httpClient, messages, thingTable);
                    if (result != null) {
                        thingTable.discoveredResult(result);
                    }
                }
            }
        }
    }

    private void showThingConfig(ShellyDeviceProfile profile) {
        if (!logger.isDebugEnabled()) {
            return;
        }

        logger.debug("{}: Initializing device {}, type {}, Hardware: Rev: {}, batch {}; Firmware: {} / {}", thingName,
                profile.device.hostname, profile.device.type, profile.hwRev, profile.hwBatchId, profile.fwVersion,
                profile.fwDate);
        logger.debug("{}: Shelly settings info for {}: {}", thingName, profile.device.hostname, profile.settingsJson);
        logger.debug("{}: Device "
                + "hasRelays:{} (numRelays={}),isRoller:{} (numRoller={}),isDimmer:{},numMeter={},isEMeter:{}), ext. Switch Add-On: {}"
                + ",isSensor:{},isDS:{},hasBattery:{}{},isSense:{},isMotion:{},isLight:{},isBulb:{},isDuo:{},isRGBW2:{},inColor:{}, BLU Gateway support: {}"
                + ",alwaysOn:{}, updatePeriod:{}sec", thingName, profile.hasRelays, profile.numRelays, profile.isRoller,
                profile.numRollers, profile.isDimmer, profile.numMeters, profile.isEMeter,
                profile.settings.extSwitch != null ? "installed" : "n/a", profile.isSensor, profile.isDW,
                profile.hasBattery,
                profile.hasBattery ? " (low battery threshold=" + config.getLowBattery() + "%)" : "", profile.isSense,
                profile.isMotion, profile.isLight, profile.isBulb, profile.isDuo, profile.isRGBW2, profile.inColor,
                profile.alwaysOn, profile.updatePeriod, apiConfig.getEnableBluGateway());
        if (profile.status.extTemperature != null || profile.status.extHumidity != null
                || profile.status.extVoltage != null || profile.status.extAnalogInput != null) {
            logger.debug("{}: Shelly Add-On detected with at least 1 external sensor", thingName);
        }
    }

    private void addStateOptions(ShellyDeviceProfile prf) {
        if (prf.isTRV) {
            String[] profileNames = prf.getValveProfileList(0);
            String channelId = mkChannelId(CHANNEL_GROUP_CONTROL, CHANNEL_CONTROL_PROFILE);
            logger.debug("{}: Adding TRV profile names to channel description: {}", thingName, profileNames);
            channelDefinitions.clearStateOptions(channelId);
            int fid = 1;
            for (String name : profileNames) {
                channelDefinitions.addStateOption(channelId, "" + fid, fid + ": " + name);
                fid++;
            }
        }
        if (prf.isRoller && prf.settings.favorites != null) {
            String channelId = mkChannelId(CHANNEL_GROUP_ROL_CONTROL, CHANNEL_ROL_CONTROL_FAV);
            logger.debug("{}: Adding {} roler favorite(s) to channel description", thingName,
                    prf.settings.favorites.size());
            channelDefinitions.clearStateOptions(channelId);
            int fid = 1;
            for (ShellyFavPos fav : prf.settings.favorites) {
                channelDefinitions.addStateOption(channelId, "" + fid, fid + ": " + fav.name);
                fid++;
            }
        }
    }

    @Override
    public String getThingType() {
        return thing.getThingTypeUID().getId();
    }

    @Override
    public ThingStatus getThingStatus() {
        return thing.getStatus();
    }

    @Override
    public ThingStatusDetail getThingStatusDetail() {
        return thing.getStatusInfo().getStatusDetail();
    }

    @Override
    public boolean isThingOnline() {
        return getThingStatus() == ThingStatus.ONLINE
                && getThingStatusDetail() != ThingStatusDetail.CONFIGURATION_PENDING;
    }

    public boolean isThingOffline() {
        return getThingStatus() == ThingStatus.OFFLINE;
    }

    @Override
    public void setThingOnline() {
        setThingOnline(true);
    }

    private void setThingOnline(boolean scheduleWarmupPolls) {
        if (!isThingOnline()) {
            updateStatus(ThingStatus.ONLINE);

            if (scheduleWarmupPolls) {
                // request 3 updates in a row (during the first 2+3*3 sec)
                requestUpdates(profile.alwaysOn ? 3 : 1, !channelsCreated);
            }
        }

        // Restart watchdog when status update was successful (no exception)
        restartWatchdog();
    }

    @Override
    public void setThingOfflineAndDisconnect(ThingStatusDetail detail, String messageKey, Object... arguments) {
        if (!isThingOffline()) {
            updateStatus(ThingStatus.OFFLINE, detail, messages.get(messageKey, arguments));
        }
        api.close(); // Gen2: disconnect WS/close http sessions
        watchdog = 0;
        profile.initialized = false; // force full re-init (incl. asyncApiRequest) on next reconnect
        channelsCreated = false; // check for new channels after devices gets re-initialized (e.g. new
    }

    @Override
    public void setThingStatus(ThingStatus status, ThingStatusDetail detail, String messageKey, Object... arguments) {
        updateStatus(status, detail, messages.get(messageKey, arguments));
    }

    @Override
    public void restartWatchdog() {
        synchronized (this) {
            watchdog = now();
        }
        updateChannel(CHANNEL_GROUP_DEV_STATUS, CHANNEL_DEVST_HEARTBEAT, getTimestamp());
        logger.trace("{}: Watchdog restarted (expires in {} sec)", thingName, profile.updatePeriod);
    }

    private boolean isWatchdogExpired() {
        double delta = now() - watchdog;
        if ((watchdog > 0) && (delta > profile.updatePeriod)) {
            stats.remainingWatchdog.set((long) delta);
            return true;
        }
        return false;
    }

    @Override
    public void reinitializeThing() {
        logger.debug("{}: Re-Initialize Thing", thingName);
        if (isStopping()) {
            logger.debug("{}: Handler is shutting down, ignore", thingName);
            return;
        }
        updateStatus(ThingStatus.ONLINE, ThingStatusDetail.CONFIGURATION_PENDING,
                messages.get("offline.status-error-restarted"));
        requestUpdates(0, true);
    }

    @Override
    public boolean isStopping() {
        return stopping;
    }

    @Override
    public void fillDeviceStatus(ShellySettingsStatus status, boolean updated) {
        String alarm = "";

        // Update uptime and WiFi, internal temp
        ShellyComponents.updateDeviceStatus(this, status);
        stats.wifiRssi.set(status.wifiSta != null && status.wifiSta.rssi != null ? status.wifiSta.rssi : 0);

        if (api.isInitialized()) {
            stats.timeoutErrors.set(api.getTimeoutErrors());
            stats.timeoutsRecovered.set(api.getTimeoutsRecovered());
        }
        stats.remainingWatchdog.set(watchdog > 0 ? (long) (now() - watchdog) : 0);

        // Check various device indicators like overheating
        if (checkRestarted(status)) {
            // Force re-initialization on next status update
            reinitializeThing();
        } else if (getBool(status.overtemperature)) {
            alarm = ALARM_TYPE_OVERTEMP;
        } else if (getBool(status.overload)) {
            alarm = ALARM_TYPE_OVERLOAD;
        } else if (getBool(status.loaderror)) {
            alarm = ALARM_TYPE_LOADERR;
        }
        State internalTemp = getChannelValue(CHANNEL_GROUP_DEV_STATUS, CHANNEL_DEVST_ITEMP);
        if (internalTemp instanceof Number number) {
            int temp = number.intValue();
            if (temp > stats.maxInternalTemp.get()) {
                stats.maxInternalTemp.set(temp);
            }
        }

        if (status.uptime != null) {
            stats.lastUptime.set(getLong(status.uptime));
        }

        if (!alarm.isEmpty()) {
            postEvent(alarm, false);
        }
    }

    @Override
    public void incProtMessages() {
        stats.protocolMessages.incrementAndGet();
    }

    @Override
    public void incProtErrors() {
        stats.protocolErrors.incrementAndGet();
    }

    /**
     * Check if device has restarted and needs a new Thing initialization
     *
     * @return true: restart detected
     */

    private boolean checkRestarted(ShellySettingsStatus status) {
        if (profile.isInitialized() && profile.alwaysOn /* exclude battery powered devices */
                && (status.uptime != null && status.uptime < stats.lastUptime.get()
                        || (profile.status.update != null && !getString(profile.status.update.oldVersion).isEmpty()
                                && !status.update.oldVersion.equals(profile.status.update.oldVersion)))) {
            logger.debug("{}: Device has been restarted, uptime={}/{}, firmware={}/{}", thingName, stats.lastUptime,
                    getLong(status.uptime), profile.status.update.oldVersion, status.update.oldVersion);
            updateProperties(profile, status);
            return true;
        }
        return false;
    }

    /**
     * Save alarm to the lastAlarm channel
     *
     * @param event Alarm Message
     * @param force
     */
    @Override
    public void postEvent(String event, boolean force) {
        String channelId = mkChannelId(CHANNEL_GROUP_DEV_STATUS, CHANNEL_DEVST_ALARM);
        State value = cache.getValue(channelId);
        String lastAlarmMsg = value != UnDefType.NULL ? value.toString() : "";
        ShellyDeviceAlarm lastAlarm = stats.lastAlarm.get();

        if (force || !lastAlarmMsg.equals(event) || (lastAlarmMsg.equals(event)
                && (lastAlarm == null || now() > lastAlarm.timeStamp() + HEALTH_CHECK_INTERVAL_SEC))) {
            switch (event.toUpperCase(Locale.ROOT)) {
                case "":
                case "0": // DW2 1.8
                case SHELLY_WAKEUPT_SENSOR:
                case SHELLY_WAKEUPT_PERIODIC:
                case SHELLY_WAKEUPT_BUTTON:
                case SHELLY_WAKEUPT_POWERON:
                case SHELLY_WAKEUPT_EXT_POWER:
                case SHELLY_WAKEUPT_UNKNOWN:
                case Shelly2ApiJsonDTO.SHELLY2_EVENT_OTASTART:
                case Shelly2ApiJsonDTO.SHELLY2_EVENT_OTAPROGRESS:
                case Shelly2ApiJsonDTO.SHELLY2_EVENT_OTADONE:
                case SHELLY_EVENT_ROLLER_CALIB:
                    logger.debug("{}: {}", thingName, messages.get("event.filtered", event));
                    break;
                case ALARM_TYPE_NONE:
                    break;
                default:
                    logger.debug("{}: {}", thingName, messages.get("event.triggered", event));
                    triggerChannel(channelId, event);
                    cache.updateChannel(channelId, getStringType(event.toUpperCase(Locale.ROOT)));
                    lastAlarm = new ShellyDeviceAlarm(event, (long) now());
                    stats.lastAlarm.set(lastAlarm);
                    stats.alarms.incrementAndGet();
            }
        }
    }

    public boolean isUpdateScheduled() {
        return scheduledUpdates > 0;
    }

    /**
     * Callback for device events
     *
     * @param address
     * @param deviceName device receiving the event
     * @param deviceIndex
     * @param type the HTML input data
     * @param parameters parameters from the event URL
     * @return true if event was processed
     */
    @Override
    public boolean onEvent(String address, String deviceName, String deviceIndex, String type,
            Map<String, String> parameters) {
        if (thingName.equalsIgnoreCase(deviceName) || address.equals(apiConfig.getBdAddr())
                || apiConfig.getRealm().equals(deviceName)) {
            logger.debug("{}: Event received: class={}, index={}, parameters={}", deviceName, type, deviceIndex,
                    parameters);
            int idx = !deviceIndex.isEmpty() ? Integer.parseInt(deviceIndex) : 1;
            if (!profile.isInitialized()) {
                logger.debug("{}: Device is not yet initialized, event triggers initialization", deviceName);
                requestUpdates(1, true);
            } else {
                String group = profile.getControlGroup(idx);
                if (group.isEmpty()) {
                    logger.debug("{}: Unsupported event class: {}", thingName, type);
                    return false;
                }

                // map some of the events to system defined button triggers
                String channel = "";
                String onoff = "";
                String payload = "";
                String parmType = getString(parameters.get("type"));
                String event = !parmType.isEmpty() ? parmType : type;
                boolean isButton = profile.inButtonMode(idx - 1) || "button".equals(type);
                switch (event) {
                    case SHELLY_EVENT_SHORTPUSH:
                    case SHELLY_EVENT_DOUBLE_SHORTPUSH:
                    case SHELLY_EVENT_TRIPLE_SHORTPUSH:
                    case SHELLY_EVENT_LONGPUSH:
                        if (isButton) {
                            triggerButton(group, idx, mapButtonEvent(event));
                            channel = CHANNEL_BUTTON_TRIGGER + profile.getInputSuffix(idx);
                            payload = Shelly1ApiJsonDTO.mapButtonEvent(event);
                        } else {
                            logger.debug("{}: Relay button is not in memontary or detached mode, ignore SHORT/LONGPUSH",
                                    thingName);
                        }
                        break;
                    case SHELLY_EVENT_BTN_ON:
                    case SHELLY_EVENT_BTN_OFF:
                        if (profile.isRGBW2) {
                            // RGBW2 has only one input, so not per channel
                            group = CHANNEL_GROUP_LIGHT_CONTROL;
                        }
                        onoff = CHANNEL_INPUT;
                        break;
                    case SHELLY_EVENT_BTN1_ON:
                    case SHELLY_EVENT_BTN1_OFF:
                        onoff = CHANNEL_INPUT1;
                        break;
                    case SHELLY_EVENT_BTN2_ON:
                    case SHELLY_EVENT_BTN2_OFF:
                        onoff = CHANNEL_INPUT2;
                        break;
                    case SHELLY_EVENT_OUT_ON:
                    case SHELLY_EVENT_OUT_OFF:
                        onoff = CHANNEL_OUTPUT;
                        break;
                    case SHELLY_EVENT_ROLLER_OPEN:
                    case SHELLY_EVENT_ROLLER_CLOSE:
                    case SHELLY_EVENT_ROLLER_STOP:
                        channel = CHANNEL_EVENT_TRIGGER;
                        payload = event;
                        break;
                    case SHELLY_EVENT_SENSORREPORT:
                        // process sensor with next refresh
                        break;
                    case SHELLY_EVENT_TEMP_OVER: // DW2
                    case SHELLY_EVENT_TEMP_UNDER:
                        channel = CHANNEL_EVENT_TRIGGER;
                        payload = event;
                        break;
                    case SHELLY_EVENT_FLOOD_DETECTED:
                    case SHELLY_EVENT_FLOOD_GONE:
                        updateChannel(group, CHANNEL_SENSOR_FLOOD,
                                OnOffType.from(event.equalsIgnoreCase(SHELLY_EVENT_FLOOD_DETECTED)));
                        break;

                    case SHELLY_EVENT_CLOSE: // DW 1.7
                    case SHELLY_EVENT_OPEN: // DW 1.7
                        updateChannel(group, CHANNEL_SENSOR_STATE,
                                event.equalsIgnoreCase(SHELLY_API_DWSTATE_OPEN) ? OpenClosedType.OPEN
                                        : OpenClosedType.CLOSED);
                        break;

                    case SHELLY_EVENT_DARK: // DW 1.7
                    case SHELLY_EVENT_TWILIGHT: // DW 1.7
                    case SHELLY_EVENT_BRIGHT: // DW 1.7
                        updateChannel(group, CHANNEL_SENSOR_ILLUM, getStringType(event));
                        break;

                    case SHELLY_EVENT_ALARM_MILD: // Shelly Gas
                    case SHELLY_EVENT_ALARM_HEAVY:
                    case SHELLY_EVENT_ALARM_OFF:
                    case SHELLY_EVENT_VIBRATION: // DW2
                        channel = CHANNEL_SENSOR_ALARM_STATE;
                        payload = event.toUpperCase(Locale.ROOT);
                        break;

                    default:
                        // trigger will be provided by input/output channel or sensor channels
                }

                if (!onoff.isEmpty()) {
                    updateChannel(group, onoff, OnOffType.from(event.toLowerCase(Locale.ROOT).contains("_on")));
                }
                if (!payload.isEmpty()) {
                    // Pass event to trigger channel
                    payload = payload.toUpperCase(Locale.ROOT);
                    logger.debug("{}: Post event {}", thingName, payload);
                    triggerChannel(mkChannelId(group, channel), payload);
                }
            }

            // request update on next interval (2x for non-battery devices)
            restartWatchdog();
            requestUpdates(scheduledUpdates >= 2 ? 0 : !profile.hasBattery ? 2 : 1, true);
            return true;
        }
        return false;
    }

    /**
     * Initialize the binding's thing configuration, calc update counts
     */
    protected boolean initializeThingConfig() {
        thingType = getThing().getThingTypeUID().getId();
        if (THING_TYPE_SHELLYUNKNOWN.equals(getThing().getThingTypeUID())) {
            setThingOfflineAndDisconnect(ThingStatusDetail.COMMUNICATION_ERROR, "offline.device-unsupported");
            return false;
        }

        // Refresh config from the current thing configuration so that changes made via
        // handleConfigurationUpdate() are picked up on every re-initialization cycle.
        config = getConfigAs(ShellyThingConfiguration.class);
        updateApiConfig();

        final Map<String, String> properties = getThing().getProperties();
        thingName = getString(properties.get(PROPERTY_SERVICE_NAME));
        if (thingName.isEmpty()) {
            thingName = getString(thingType + "-" + getString(getThing().getUID().getId())).toLowerCase(Locale.ROOT);
        }

        if (blu) {
            String bdAddr = apiConfig.getBdAddr();
            if (bdAddr == null || bdAddr.isBlank()) {
                // may not be set in .things file
                setThingOfflineAndDisconnect(ThingStatusDetail.CONFIGURATION_ERROR,
                        "config-status.error.missing-device-address");
                return false;

            }
        } else {
            if (!apiConfig.resolveIp()) {
                // may not be set in .things file
                setThingOfflineAndDisconnect(ThingStatusDetail.CONFIGURATION_ERROR,
                        "config-status.error.resolve-failed", apiConfig.getDeviceHostAddress());
                return false;
            }
        }

        if (apiConfig.getLocalIp().startsWith("169.254")) {
            setThingOfflineAndDisconnect(ThingStatusDetail.CONFIGURATION_ERROR, "config-status.error.network-config",
                    apiConfig.getLocalIp());
            return false;
        }

        // Try to get updatePeriod from properties
        // For battery devinities the REST call to get the settings will most likely fail, because the device is in
        // sleep mode. Therefore we use the last saved property value as default. Will be overwritten, when device is
        // initialized successfully by the REST call.
        String lastPeriod = getString(properties.get(PROPERTY_UPDATE_PERIOD));
        if (!lastPeriod.isEmpty()) {
            int period = Integer.parseInt(lastPeriod);
            if (period > 0) {
                profile.updatePeriod = period;
            }
        }

        int updateInterval = config.getUpdateInterval();
        if (updateInterval == 0) {
            updateInterval = UPDATE_STATUS_INTERVAL_SECONDS * UPDATE_SKIP_COUNT;
        }
        if (updateInterval < UPDATE_MIN_DELAY) {
            updateInterval = UPDATE_MIN_DELAY;
        }
        skipCount = updateInterval / UPDATE_STATUS_INTERVAL_SECONDS;
        if (logger.isTraceEnabled()) {
            logger.trace("{}: updateInterval = {}s -> skipCount = {}", thingName, updateInterval, skipCount);
        }

        return true;
    }

    private void checkVersion(ShellyDeviceProfile prf, ShellySettingsStatus status) {
        if (prf.fwVersion.isEmpty()) {
            // no fw version available (e.g. BLU device)
            return;
        }
        ShellyVersionDTO version = new ShellyVersionDTO();
        if (version.checkBeta(getString(prf.fwVersion))) {
            logger.info("{}: {}", prf.device.hostname, messages.get("versioncheck.beta", prf.fwVersion, prf.fwDate));
        } else {
            String minVersion = !gen2 ? SHELLY_API_MIN_FWVERSION : SHELLY2_API_MIN_FWVERSION;
            if (version.compare(prf.fwVersion, minVersion) < 0) {
                logger.warn("{}: {}", prf.device.hostname,
                        messages.get("versioncheck.tooold", prf.fwVersion, prf.fwDate, minVersion));
            }
        }
        if (!gen2 && bindingConfig.isAutoCoIoT() && (version.compare(prf.fwVersion, SHELLY_API_MIN_FWCOIOT) >= 0
                || "production_test".equalsIgnoreCase(prf.fwVersion))) {
            logger.debug("{}: {}", thingName, messages.get("versioncheck.autocoiot"));
            autoCoIoT = true;
        }
        if (getBool(status.update.hasUpdate) && !version.checkBeta(getString(prf.fwVersion))) {
            logger.info("{}: {}", thingName,
                    messages.get("versioncheck.update", status.update.oldVersion, status.update.newVersion));
        }
    }

    public String checkForUpdate() {
        try {
            ShellyOtaCheckResult result = api.checkForUpdate();
            return result.status;
        } catch (ShellyApiException e) {
            return "";
        }
    }

    public void startCoap(ShellyDeviceProfile profile) throws ShellyApiException {
        if (coap == null || !apiConfig.getEnableCoIOT()) {
            return;
        }
        if (profile.settings.coiot != null && profile.settings.coiot.enabled != null) {
            String devpeer = getString(profile.settings.coiot.peer);
            String ourpeer = apiConfig.getLocalIp() + ":" + Shelly1CoapJSonDTO.COIOT_PORT;
            if (!profile.settings.coiot.enabled || (profile.isMotion && devpeer.isEmpty())) {
                try {
                    api.setCoIoTPeer(ourpeer);
                    logger.info("{}: CoIoT peer updated to {}", thingName, ourpeer);
                } catch (ShellyApiException e) {
                    logger.debug("{}: Unable to set CoIoT peer: {}", thingName, e.toString());
                }
            } else if (!devpeer.isEmpty() && !devpeer.equals(ourpeer)) {
                logger.warn("{}: CoIoT peer in device settings does not point this to this host", thingName);
            }
        }
        if (autoCoIoT) {
            logger.debug("{}: Auto-CoIoT is enabled, disabling action urls", thingName);
            apiConfig.setEnableCoIOT(true);
        }

        logger.debug("{}: Starting CoIoT (autoCoIoT={}/{})", thingName, bindingConfig.isAutoCoIoT(), autoCoIoT);
        Shelly1CoapHandler coap = this.coap;
        if (coap != null) {
            coap.start();
        }
    }

    /**
     * Change type of this thing.
     *
     * @param thingType thing type acc. to the xml definition
     * @param mode Device mode (e.g. relay, roller)
     */
    protected void changeThingType(String thingType, String mode) {
        String deviceType = substringBefore(thingType, "-");
        ThingTypeUID thingTypeUID = ShellyThingCreator.getThingTypeUID(thingType, deviceType, mode);
        if (!thingTypeUID.equals(THING_TYPE_SHELLYUNKNOWN)) {
            logger.debug("{}: Changing thing type to {}", getThing().getLabel(), thingTypeUID);
            Map<String, String> properties = editProperties();
            properties.replace(PROPERTY_DEV_TYPE, deviceType);
            properties.replace(PROPERTY_DEV_MODE, mode);
            updateProperties(properties);
            changeThingType(thingTypeUID, getConfig());
        } else {
            logger.debug("{}:  to {}", thingName, thingType);
            setThingOfflineAndDisconnect(ThingStatusDetail.CONFIGURATION_ERROR,
                    "Unable to change thing type to " + thingType);
        }
    }

    @Override
    public void thingUpdated(Thing thing) {
        logger.debug("{}: Channel definitions updated.", thingName);
        super.thingUpdated(thing);
    }

    /**
     * Start the background updates
     */
    protected void startUpdateJob() {
        ScheduledFuture<?> statusJob = this.statusJob;
        if ((statusJob == null) || statusJob.isCancelled()) {
            this.statusJob = scheduler.scheduleWithFixedDelay(this::refreshStatus, 2, UPDATE_STATUS_INTERVAL_SECONDS,
                    TimeUnit.SECONDS);
            logger.debug("{}: Update status job started, interval={}*{}={}sec.", thingName, skipCount,
                    UPDATE_STATUS_INTERVAL_SECONDS, skipCount * UPDATE_STATUS_INTERVAL_SECONDS);
        }
    }

    /**
     * Flag the status job to do an exceptional update (something happened) rather
     * than waiting until the next regular poll
     *
     * @param requestCount number of polls to execute
     * @param refreshSettings true=force a /settings query
     * @return true=Update schedule, false=skipped (too many updates already
     *         scheduled)
     */
    @Override
    public boolean requestUpdates(int requestCount, boolean refreshSettings) {
        this.refreshSettings |= refreshSettings;
        if (refreshSettings) {
            if (requestCount == 0) {
                logger.debug("{}: Request settings refresh", thingName);
            }
            scheduledUpdates = 1;
            return true;
        }
        if (scheduledUpdates < 10) { // < 30s
            scheduledUpdates += requestCount;
            return true;
        }
        return false;
    }

    /**
     * Map input states to channels
     *
     * @param status Shelly device status
     * @return true: one or more inputs were updated
     */
    @Override
    public boolean updateInputs(ShellySettingsStatus status) {
        boolean updated = false;

        if (status.inputs != null) {
            if (!areChannelsCreated()) {
                updateChannelDefinitions(ShellyChannelDefinitions.createInputChannels(thing, profile, status));
            }

            int idx = 0;
            boolean multiInput = !profile.isIX && status.inputs.size() >= 2; // device has multiple SW (inputs)
            for (ShellyInputState input : status.inputs) {
                String group = profile.getInputGroup(idx);
                String suffix = multiInput ? profile.getInputSuffix(idx) : "";
                updated |= updateChannel(group, CHANNEL_INPUT + suffix, getOnOff(input.input));
                if (input.event != null) {
                    updated |= updateChannel(group, CHANNEL_STATUS_EVENTTYPE + suffix, getStringType(input.event));
                    updated |= updateChannel(group, CHANNEL_STATUS_EVENTCOUNT + suffix, getDecimal(input.eventCount));
                }
                idx++;
            }
        } else {
            if (status.input != null) {
                // RGBW2: a single int rather than an array
                return updateChannel(profile.getControlGroup(0), CHANNEL_INPUT,
                        OnOffType.from(getInteger(status.input) != 0));
            }
        }
        return updated;
    }

    @Override
    public boolean updateWakeupReason(@Nullable List<Object> valueArray) {
        boolean changed = false;
        if (valueArray != null && !valueArray.isEmpty()) {
            String reason = getString((String) valueArray.get(0));
            String newVal = valueArray.toString();
            changed = updateChannel(CHANNEL_GROUP_DEV_STATUS, CHANNEL_DEVST_WAKEUP, getStringType(reason));
            changed |= !lastWakeupReason.isEmpty() && !lastWakeupReason.equals(newVal);
            if (changed) {
                postEvent(reason.toUpperCase(Locale.ROOT), true);
            }
            lastWakeupReason = newVal;
        }
        return changed;
    }

    @Override
    public void triggerButton(String group, int idx, String value) {
        String trigger = mapButtonEvent(value);
        if (trigger.isEmpty()) {
            return;
        }

        logger.debug("{}: Update button state with {}/{}", thingName, value, trigger);
        triggerChannel(group,
                profile.isRoller ? CHANNEL_EVENT_TRIGGER : CHANNEL_BUTTON_TRIGGER + profile.getInputSuffix(idx),
                trigger);
        updateChannel(group, CHANNEL_LAST_UPDATE, getTimestamp());
        if (profile.alwaysOn) {
            // refresh status of the input channel
            requestUpdates(1, false);
        }
    }

    @Override
    public void publishState(String channelId, State value) {
        String id = channelId.contains("$") ? substringBefore(channelId, "$") : channelId;
        if (!stopping && isLinked(id)) {
            updateState(id, value);
            logger.debug("{}: Channel {} updated with {} (type {}).", thingName, channelId, value, value.getClass());
        }
    }

    @Override
    public boolean updateChannel(String group, String channel, State value) {
        return updateChannel(mkChannelId(group, channel), value, false);
    }

    @Override
    public boolean updateChannel(String channelId, State value, boolean force) {
        if (stopping) {
            return false;
        }
        String replacementChannelId = ShellyChannelDefinitions.getReplacementChannelId(channelId);
        if (replacementChannelId != null) {
            warnDeprecatedChannel(channelId, replacementChannelId);
            boolean updated = cache.updateChannel(channelId, value, force);
            updated |= cache.updateChannel(replacementChannelId, value, force);
            return updated;
        }
        return cache.updateChannel(channelId, value, force);
    }

    private synchronized void warnDeprecatedChannel(String channelId, String replacementChannelId) {
        if (!isLinked(channelId)) {
            return;
        }
        long now = System.currentTimeMillis();
        Long lastWarning = deprecatedChannelWarnings.get(channelId);
        if (lastWarning == null || now - lastWarning >= DEPRECATED_CHANNEL_WARNING_INTERVAL_MS) {
            deprecatedChannelWarnings.put(channelId, now);
            logger.warn("{}: Channel {} is deprecated and will be removed in a future release; use {} instead.",
                    thingName, channelId, replacementChannelId);
        }
    }

    @Override
    public State getChannelValue(String group, String channel) {
        return cache.getValue(group, channel);
    }

    @Override
    public double getChannelDouble(String group, String channel) {
        State value = getChannelValue(group, channel);
        if (value != UnDefType.NULL) {
            if (value instanceof QuantityType<?> quantityCommand) {
                return quantityCommand.toBigDecimal().doubleValue();
            }
            if (value instanceof DecimalType decimalCommand) {
                return decimalCommand.doubleValue();
            }
        }
        return -1;
    }

    /**
     * Update Thing's channels according to available status information from the API
     *
     * @param dynChannels
     */
    @Override
    public void updateChannelDefinitions(Map<String, Channel> dynChannels) {
        if (channelsCreated) {
            return; // already done
        }
        addMissingChannelDefinitions(dynChannels);
    }

    @Override
    public boolean updateThingChannels(Map<String, Channel> channelUpdates, Map<String, Channel> newChannels) {
        boolean updated = replaceChannelDefinitions(channelUpdates);
        updated |= addMissingChannelDefinitions(newChannels);
        return updated;
    }

    private boolean replaceChannelDefinitions(Map<String, Channel> channelUpdates) {
        if (channelUpdates.isEmpty()) {
            return false;
        }
        try {
            ThingBuilder thingBuilder = editThing();
            List<Channel> existingChannels = getThing().getChannels();
            boolean changed = false;
            for (Map.Entry<String, Channel> channelUpdate : channelUpdates.entrySet()) {
                Channel oldChannel = ShellyChannelMigration.findChannel(existingChannels, channelUpdate.getKey());
                if (oldChannel != null) {
                    Channel newChannel = channelUpdate.getValue();
                    logger.debug("{}: Updating channel {}", thingName, newChannel.getUID().getId());
                    thingBuilder.withoutChannel(oldChannel.getUID());
                    thingBuilder.withChannel(newChannel);
                    changed = true;
                }
            }
            if (changed) {
                updateThing(thingBuilder.build());
                logger.debug("{}: Channel definitions updated", thingName);
            }
            return changed;
        } catch (IllegalArgumentException e) {
            logger.debug("{}: Unable to update channel definitions", thingName, e);
        }
        return false;
    }

    private boolean addMissingChannelDefinitions(Map<String, Channel> dynChannels) {
        try {
            List<Channel> existingChannels = getThing().getChannels();
            for (Channel channel : existingChannels) {
                String id = channel.getUID().getId();
                if (dynChannels.containsKey(id)) {
                    dynChannels.remove(id);
                }
            }

            if (!dynChannels.isEmpty()) {
                logger.debug("{}: Updating channel definitions, {} channels", thingName, dynChannels.size());
                ThingBuilder thingBuilder = editThing();
                for (Map.Entry<String, Channel> channel : dynChannels.entrySet()) {
                    Channel c = channel.getValue();
                    logger.debug("{}: Adding channel {}", thingName, c.getUID().getId());
                    thingBuilder.withChannel(c);
                }
                updateThing(thingBuilder.build());
                logger.debug("{}: Channel definitions updated", thingName);
                return true;
            }
        } catch (IllegalArgumentException e) {
            logger.debug("{}: Unable to update channel definitions", thingName, e);
        }
        return false;
    }

    @Override
    public boolean areChannelsCreated() {
        return channelsCreated;
    }

    /**
     * Update thing properties with dynamic values
     *
     * @param profile The device profile
     * @param status the /status result
     */
    public void updateProperties(ShellyDeviceProfile profile, ShellySettingsStatus status) {
        Map<String, String> properties = fillDeviceProperties(profile);
        String deviceName = getString(profile.settings.name);
        properties.put(PROPERTY_SERVICE_NAME, apiConfig.getRealm());
        properties.put(PROPERTY_DEV_AUTH, getBool(profile.device.auth) ? "yes" : "no");
        if (!deviceName.isEmpty()) {
            properties.put(PROPERTY_DEV_NAME, deviceName);
        }

        // add status properties
        if (status.wifiSta != null) {
            properties.put(PROPERTY_WIFI_NETW, getString(status.wifiSta.ssid));
        }
        if (status.update != null) {
            properties.put(PROPERTY_UPDATE_STATUS, getString(status.update.status));
            properties.put(PROPERTY_UPDATE_AVAILABLE, getBool(status.update.hasUpdate) ? "yes" : "no");
            properties.put(PROPERTY_UPDATE_CURR_VERS, getString(status.update.oldVersion));
            properties.put(PROPERTY_UPDATE_NEW_VERS, getString(status.update.newVersion));
        }
        properties.put(PROPERTY_COIOTAUTO, String.valueOf(autoCoIoT));

        flushProperties(properties);
    }

    /**
     * Add one property to the Thing Properties
     *
     * @param key Name of the property
     * @param value Value of the property
     */
    @Override
    public void updateProperties(String key, String value) {
        Map<String, String> thingProperties = editProperties();
        thingProperties.put(key, value);
        updateProperties(thingProperties);
        logger.trace("{}: Properties updated", thingName);
    }

    public void flushProperties(Map<String, String> propertyUpdates) {
        Map<String, String> thingProperties = editProperties();
        thingProperties.putAll(propertyUpdates);
        updateProperties(thingProperties);
    }

    /**
     * Get one property from the Thing Properties
     *
     * @param key property name
     * @return property value or "" if property is not set
     */
    @Override
    public String getProperty(String key) {
        Map<String, String> thingProperties = getThing().getProperties();
        return getString(thingProperties.get(key));
    }

    /**
     * Fill Thing Properties with device attributes
     *
     * @param profile Property Map to full
     * @return a full property map
     */
    public static Map<String, String> fillDeviceProperties(ShellyDeviceProfile profile) {
        Map<String, String> properties = new HashMap<>();
        properties.put(PROPERTY_VENDOR, VENDOR);
        if (profile.isInitialized()) {
            properties.put(PROPERTY_MODEL_ID, getString(profile.device.type));
            properties.put(PROPERTY_MAC_ADDRESS, profile.device.mac);
            properties.put(PROPERTY_FIRMWARE_VERSION, profile.fwVersion + "/" + profile.fwDate);
            properties.put(PROPERTY_DEV_MODE, profile.device.mode);
            if (profile.hasRelays) {
                properties.put(PROPERTY_NUM_RELAYS, String.valueOf(profile.numRelays));
                properties.put(PROPERTY_NUM_ROLLERS, String.valueOf(profile.numRollers));
                properties.put(PROPERTY_NUM_METER, String.valueOf(profile.numMeters));
            }
            properties.put(PROPERTY_UPDATE_PERIOD, String.valueOf(profile.updatePeriod));
            if (!profile.hwRev.isEmpty()) {
                properties.put(PROPERTY_HWREV, profile.hwRev);
                properties.put(PROPERTY_HWBATCH, profile.hwBatchId);
            }
        }
        return properties;
    }

    /**
     * Return device profile.
     *
     * @param forceRefresh true=force refresh before returning, false=return without
     *            refresh
     * @return ShellyDeviceProfile instance
     * @throws ShellyApiException
     */
    @Override
    public ShellyDeviceProfile getProfile(boolean forceRefresh) throws ShellyApiException {
        try {
            refreshSettings |= forceRefresh;
            if (refreshSettings) {
                profile = api.getDeviceProfile(thing.getThingTypeUID(), null);
                if (!isThingOnline()) {
                    logger.debug("{}: Device profile re-initialized (thingType={})", thingName, thingType);
                }
            }
        } catch (ShellyApiException | RuntimeException e) {
            logger.debug("{}: Unable to initialize Device Profile", thingName, e);
        } finally {
            refreshSettings = false;
        }
        return profile;
    }

    @Override
    public ShellyDeviceProfile getProfile() {
        return profile;
    }

    @Override
    public @Nullable List<StateOption> getStateOptions(ChannelTypeUID uid) {
        List<StateOption> options = channelDefinitions.getStateOptions(uid);
        if (!options.isEmpty()) {
            logger.debug("{}: Return {} state options for channel uid {}", thingName, options.size(), uid.getId());
            return options;
        }
        return null;
    }

    protected ShellyDeviceProfile getDeviceProfile() {
        return profile;
    }

    @Override
    public void triggerChannel(String group, String channel, String payload) {
        String triggerCh = mkChannelId(group, channel);
        logger.debug("{}: Send event {} to channel {}", thingName, triggerCh, payload);
        if (EVENT_TYPE_VIBRATION.contentEquals(payload)) {
            if (vibrationFilter == 0) {
                vibrationFilter = VIBRATION_FILTER_SEC / UPDATE_STATUS_INTERVAL_SECONDS + 1;
                logger.debug("{}: Duplicate vibration events will be absorbed for the next {} sec", thingName,
                        vibrationFilter * UPDATE_STATUS_INTERVAL_SECONDS);
            } else {
                logger.debug("{}: Vibration event absorbed, {} sec remaining", thingName,
                        vibrationFilter * UPDATE_STATUS_INTERVAL_SECONDS);
                return;
            }
        }

        triggerChannel(triggerCh, payload);
    }

    public void stop() {
        logger.debug("{}: Shutting down", thingName);
        ScheduledFuture<?> job = this.initJob;
        if (job != null) {
            job.cancel(true);
            initJob = null;
        }
        job = this.statusJob;
        if (job != null) {
            job.cancel(true);
            statusJob = null;
            logger.debug("{}: Shelly statusJob stopped", thingName);
        }
        api.close();
        profile.initialized = false;
    }

    /**
     * Shutdown thing, make sure background jobs are canceled
     */
    @Override
    public void dispose() {
        logger.debug("{}: Stopping Thing", thingName);
        stopping = true;
        stop();
        super.dispose();
    }

    /**
     * Device specific command handlers are overriding this method to do additional stuff
     */
    public boolean handleDeviceCommand(ChannelUID channelUID, Command command) throws ShellyApiException {
        return false;
    }

    public String getUID() {
        return getThing().getUID().getAsString();
    }

    /**
     * Device specific handlers are overriding this method to do additional stuff
     */
    public boolean updateDeviceStatus(ShellySettingsStatus status) throws ShellyApiException {
        return false;
    }

    @Override
    public String getThingName() {
        return thingName;
    }

    @Override
    public void resetStats() {
        // reset statistics
        stats = new ShellyDeviceStats();
    }

    @Override
    public ShellyDeviceStats getStats() {
        return stats;
    }

    @Override
    public ShellyApiInterface getApi() {
        return api;
    }

    @Override
    public long getScheduledUpdates() {
        return scheduledUpdates;
    }

    public Map<String, String> getStatsProp() {
        return stats.asProperties();
    }

    @Override
    public void triggerUpdateFromCoap() {
        if ((!autoCoIoT && (getScheduledUpdates() < 1)) || (autoCoIoT && !profile.isLight && !profile.hasBattery)) {
            requestUpdates(1, false);
        }
    }
}
