/*
 * Copyright (c) 2010-2026 Contributors to the openHAB project
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0
 *
 * SPDX-License-Identifier: EPL-2.0
 */
package org.openhab.binding.shelly.internal.handler;

import static org.openhab.binding.shelly.internal.ShellyBindingConstants.*;
import static org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.*;
import static org.openhab.binding.shelly.internal.util.ShellyUtils.*;

import java.util.List;
import java.util.Locale;

import javax.measure.MetricPrefix;
import javax.measure.Unit;
import javax.measure.quantity.Pressure;

import org.eclipse.jdt.annotation.NonNullByDefault;
import org.eclipse.jdt.annotation.Nullable;
import org.openhab.binding.shelly.internal.api.ShellyApiException;
import org.openhab.binding.shelly.internal.api.ShellyDeviceProfile;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellyRollerStatus;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellySettingsDimmer;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellySettingsEMeter;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellySettingsLight;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellySettingsMeter;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellySettingsRelay;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellySettingsStatus;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellyShortLightStatus;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellyStatusSensor;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellyStatusSensor.ShellyADC;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellyStatusSensor.ShellyExtAnalogInput;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellyStatusSensor.ShellyExtAnalogInput.ShellyShortAnalogInput;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellyStatusSensor.ShellyExtDigitalInput;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellyStatusSensor.ShellyExtDigitalInput.ShellyShortDigitalInput;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellyStatusSensor.ShellyExtHumidity;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellyStatusSensor.ShellyExtHumidity.ShellyShortHum;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellyStatusSensor.ShellyExtTemperature;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellyStatusSensor.ShellyExtTemperature.ShellyShortTemp;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellyStatusSensor.ShellyExtVoltage;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellyStatusSensor.ShellyExtVoltage.ShellyShortVoltage;
import org.openhab.binding.shelly.internal.api1.Shelly1ApiJsonDTO.ShellyThermnostat;
import org.openhab.binding.shelly.internal.provider.ShellyChannelDefinitions;
import org.openhab.core.library.types.OnOffType;
import org.openhab.core.library.types.StringType;
import org.openhab.core.library.unit.ImperialUnits;
import org.openhab.core.library.unit.SIUnits;
import org.openhab.core.library.unit.Units;
import org.openhab.core.types.State;
import org.openhab.core.types.UnDefType;

import com.google.gson.Gson;

/***
 * The{@link ShellyComponents} implements updates for supplemental components
 * Meter will be used by Relay + Light; Sensor is part of H&amp;T, Flood, Door Window, Sense
 *
 * @author Markus Michels - Initial contribution
 */
@NonNullByDefault
public class ShellyComponents {

    /**
     * Update device status
     *
     * @param thingHandler Thing Handler instance
     * @param status Status message
     */
    public static boolean updateDeviceStatus(ShellyThingInterface thingHandler, ShellySettingsStatus status) {
        ShellyDeviceProfile profile = thingHandler.getProfile();

        if (!thingHandler.areChannelsCreated()) {
            thingHandler.updateChannelDefinitions(ShellyChannelDefinitions.createDeviceChannels(thingHandler.getThing(),
                    thingHandler.getProfile(), status));
        }

        thingHandler.updateChannel(CHANNEL_GROUP_DEV_STATUS, CHANNEL_DEVST_FIRMWARE, getStringType(profile.fwVersion));

        if (!profile.gateway.isEmpty()) {
            thingHandler.updateChannel(CHANNEL_GROUP_DEV_STATUS, CHANNEL_DEVST_GATEWAY, getStringType(profile.gateway));
        }

        if (getLong(status.uptime) > 10) {
            thingHandler.updateChannel(CHANNEL_GROUP_DEV_STATUS, CHANNEL_DEVST_UPTIME,
                    toQuantityType((double) getLong(status.uptime), DIGITS_NONE, Units.SECOND));
        }

        Integer rssi = getInteger(status.wifiSta.rssi);
        thingHandler.updateChannel(CHANNEL_GROUP_DEV_STATUS, CHANNEL_DEVST_RSSI, mapSignalStrength(rssi));
        if (status.tmp != null && getBool(status.tmp.isValid) && !thingHandler.getProfile().isSensor
                && status.tmp.tC != SHELLY_API_INVTEMP) {
            thingHandler.updateChannel(CHANNEL_GROUP_DEV_STATUS, CHANNEL_DEVST_ITEMP,
                    toQuantityType(getDouble(status.tmp.tC), DIGITS_TEMP, SIUnits.CELSIUS));
        } else if (status.temperature != null && status.temperature != SHELLY_API_INVTEMP) {
            thingHandler.updateChannel(CHANNEL_GROUP_DEV_STATUS, CHANNEL_DEVST_ITEMP,
                    toQuantityType(getDouble(status.temperature), DIGITS_NONE, SIUnits.CELSIUS));
        }
        thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_SLEEPTIME,
                toQuantityType(getInteger(status.sleepTime), Units.SECOND));

        thingHandler.updateChannel(CHANNEL_GROUP_DEV_STATUS, CHANNEL_DEVST_UPDATE, getOnOff(status.hasUpdate));

        if (profile.settings.calibrated != null) {
            thingHandler.updateChannel(CHANNEL_GROUP_DEV_STATUS, CHANNEL_DEVST_CALIBRATED,
                    getOnOff(profile.settings.calibrated));
        }

        return false; // device status never triggers update
    }

    public static boolean updateRelay(ShellyBaseHandler thingHandler, ShellySettingsStatus status, int id) {
        ShellyDeviceProfile profile = thingHandler.getProfile();
        ShellySettingsRelay relay = status.relays.get(id);
        ShellySettingsRelay rsettings;
        List<ShellySettingsRelay> relays = profile.settings.relays;
        if (relays != null) {
            rsettings = relays.get(id);
        } else {
            throw new IllegalArgumentException("No relay settings");
        }

        boolean updated = false;
        if (relay.isValid == null || relay.isValid) {
            String groupName = profile.getControlGroup(id);
            updated |= thingHandler.updateChannel(groupName, CHANNEL_OUTPUT_NAME, getStringType(rsettings.name));

            if (getBool(relay.overpower)) {
                thingHandler.postEvent(ALARM_TYPE_OVERPOWER, false);
            }

            if (relay.ison != null) {
                // null means no cycle has reported the output state yet - don't flatten that to OFF
                updated |= thingHandler.updateChannel(groupName, CHANNEL_OUTPUT, getOnOff(relay.ison));
            }
            updated |= thingHandler.updateChannel(groupName, CHANNEL_TIMER_ACTIVE, getOnOff(relay.hasTimer));
            if (status.extSwitch != null) {
                if (status.extSwitch.input0 != null) {
                    updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_ESENSOR_INPUT1,
                            getOpenClosed(getInteger(status.extSwitch.input0.input) == 1));
                }
            }

            // Update Auto-ON/OFF timer
            updated |= thingHandler.updateChannel(groupName, CHANNEL_TIMER_AUTOON,
                    toQuantityType(getDouble(rsettings.autoOn), Units.SECOND));
            updated |= thingHandler.updateChannel(groupName, CHANNEL_TIMER_AUTOOFF,
                    toQuantityType(getDouble(rsettings.autoOff), Units.SECOND));
        }
        return updated;
    }

    public static boolean updateRoller(ShellyBaseHandler thingHandler, ShellyRollerStatus control, int id)
            throws ShellyApiException {
        ShellyDeviceProfile profile = thingHandler.getProfile();
        boolean updated = false;
        if (getBool(control.isValid)) {
            String groupName = profile.getControlGroup(id);
            if (control.name != null) {
                updated |= thingHandler.updateChannel(groupName, CHANNEL_OUTPUT_NAME, getStringType(control.name));
            }

            String state = getString(control.state);
            int pos = -1;
            switch (state) {
                case SHELLY_ALWD_ROLLER_TURN_OPEN:
                    pos = SHELLY_MAX_ROLLER_POS;
                    break;
                case SHELLY_ALWD_ROLLER_TURN_CLOSE:
                    pos = SHELLY_MIN_ROLLER_POS;
                    break;
                case SHELLY_ALWD_ROLLER_TURN_STOP:
                    if (control.currentPos != null) {
                        // only valid in stop state
                        pos = Math.max(SHELLY_MIN_ROLLER_POS, Math.min(control.currentPos, SHELLY_MAX_ROLLER_POS));
                    }
                    break;
            }
            if (pos != -1) {
                thingHandler.logger.debug("{}: Update roller position to {}/{}, state={}", thingHandler.thingName, pos,
                        SHELLY_MAX_ROLLER_POS - pos, state);
                updated |= thingHandler.updateChannel(groupName, CHANNEL_ROL_CONTROL_CONTROL,
                        toQuantityType((double) (SHELLY_MAX_ROLLER_POS - pos), Units.PERCENT));
                updated |= thingHandler.updateChannel(groupName, CHANNEL_ROL_CONTROL_POS,
                        toQuantityType((double) pos, Units.PERCENT));
            }

            updated |= thingHandler.updateChannel(groupName, CHANNEL_ROL_CONTROL_STATE, new StringType(state));
            updated |= thingHandler.updateChannel(groupName, CHANNEL_ROL_CONTROL_STOPR,
                    getStringType(control.stopReason));
            updated |= thingHandler.updateChannel(groupName, CHANNEL_ROL_CONTROL_SAFETY,
                    getOnOff(control.safetySwitch));
        }
        return updated;
    }

    /**
     * Update Meter channel
     *
     * @param thingHandler Thing Handler instance
     * @param status Last ShellySettingsStatus
     */
    public static boolean updateMeters(ShellyThingInterface thingHandler, ShellySettingsStatus status) {
        ShellyDeviceProfile profile = thingHandler.getProfile();
        if (status.meters == null && status.emeters == null) {
            return false;
        }
        if ((profile.isRoller || profile.isRGBW2) && !profile.isGen2) {
            return updateAggregatedMeter(thingHandler, status, profile);
        } else if (profile.isEMeter) {
            return updateEMeters(thingHandler, status, profile);
        } else {
            return updateSimpleMeters(thingHandler, status, profile);
        }
    }

    private static boolean updateSimpleMeters(ShellyThingInterface thingHandler, ShellySettingsStatus status,
            ShellyDeviceProfile profile) {
        if (status.meters == null) {
            return false;
        }
        double accumulatedWatts = 0.0;
        double accumulatedTotal = 0.0;
        boolean totalPresent = false;
        boolean updated = false;
        boolean createChannels = !thingHandler.areChannelsCreated();
        int m = 0;
        for (ShellySettingsMeter meter : status.meters) {
            if (m >= profile.numMeters) {
                // Shelly1: reports status.meters[0].is_valid = true, but even doesn't have a meter
                break;
            }
            if (getBool(meter.isValid) || profile.isLight) { // RGBW2-white doesn't report valid flag correctly
                String groupName = profile.getMeterGroup(m);
                if (createChannels) {
                    if (!profile.isBulb) { // skip for Shelly Bulb: JSON has a meter, but values don't get updated
                        thingHandler.updateChannelDefinitions(ShellyChannelDefinitions
                                .createMeterChannels(thingHandler.getThing(), profile, meter, groupName));
                    }
                }
                updated |= thingHandler.updateChannel(groupName, CHANNEL_METER_CURRENTWATTS,
                        toQuantityType(getDouble(meter.power), DIGITS_WATT, Units.WATT));
                accumulatedWatts += getDouble(meter.power);
                if (meter.total != null) {
                    double kwh = getDouble(meter.total) / 1000 / 60; // convert Watt/Min to kWh
                    updated |= thingHandler.updateChannel(groupName, CHANNEL_METER_TOTALKWH,
                            toQuantityType(kwh, DIGITS_KWH, Units.KILOWATT_HOUR));
                    accumulatedTotal += kwh;
                    totalPresent = true;
                }
                updated |= updateMinuteCounters(thingHandler, groupName, meter.counters);
                if (meter.timestamp != null) {
                    thingHandler.updateChannel(groupName, CHANNEL_LAST_UPDATE,
                            getTimestamp(getString(profile.settings.timezone), meter.timestamp));
                }
            }
            m++;
        }
        updateDeviceStatusTotals(thingHandler, status, accumulatedWatts, accumulatedTotal, totalPresent, 0.0, false,
                0.0, false);
        return updated;
    }

    private static boolean updateEMeters(ShellyThingInterface thingHandler, ShellySettingsStatus status,
            ShellyDeviceProfile profile) {
        if (status.emeters == null) {
            return false;
        }
        double accumulatedWatts = 0.0;
        double accumulatedTotal = 0.0;
        double accumulatedReturned = 0.0;
        double accumulatedApparent = 0.0;
        boolean totalPresent = false;
        boolean returnedPresent = false;
        boolean apparentPresent = false;
        boolean updated = false;
        boolean createChannels = !thingHandler.areChannelsCreated();

        if (status.neutralCurrent != null) {
            if (createChannels) {
                thingHandler.updateChannelDefinitions(ShellyChannelDefinitions.createEMNCurrentChannels(
                        thingHandler.getThing(), profile.settings.neutralCurrent, status.neutralCurrent));
            }
            if (getBool(status.neutralCurrent.isValid)) {
                String ngroup = CHANNEL_GROUP_NMETER;
                updated |= thingHandler.updateChannel(ngroup, CHANNEL_NMETER_CURRENT,
                        toQuantityType(getDouble(status.neutralCurrent.current), DIGITS_AMPERE, Units.AMPERE));
                updated |= thingHandler.updateChannel(ngroup, CHANNEL_NMETER_IXSUM,
                        toQuantityType(getDouble(status.neutralCurrent.ixsum), DIGITS_AMPERE, Units.AMPERE));
                // mismatchThreshold is only available from Gen1 device settings; Gen2 devices omit it
                if (profile.settings.neutralCurrent != null) {
                    updated |= thingHandler.updateChannel(ngroup, CHANNEL_NMETER_MTRESHHOLD, toQuantityType(
                            getDouble(profile.settings.neutralCurrent.mismatchThreshold), DIGITS_AMPERE, Units.AMPERE));
                }
                updated |= thingHandler.updateChannel(ngroup, CHANNEL_NMETER_MISMATCH,
                        getOnOff(status.neutralCurrent.mismatch));
            }
        }

        int m = 0;
        for (ShellySettingsEMeter emeter : status.emeters) {
            if (m >= profile.numMeters) {
                break;
            }

            String groupName = profile.getMeterGroup(m);
            boolean meterUpdated = false;

            // Always create channels regardless of data validity — Gen2 first WS push may lack emdata
            if (createChannels) {
                thingHandler.updateChannelDefinitions(ShellyChannelDefinitions
                        .createEMeterChannels(thingHandler.getThing(), profile, emeter, groupName));
            }
            if (getBool(emeter.isValid)) {
                if (emeter.power != null) {
                    meterUpdated |= thingHandler.updateChannel(groupName, CHANNEL_METER_CURRENTWATTS,
                            toQuantityType(emeter.power, DIGITS_WATT, Units.WATT));
                }
                if (emeter.total != null) {
                    double total = emeter.total / 1000; // convert Wh to kWh
                    meterUpdated |= thingHandler.updateChannel(groupName, CHANNEL_METER_TOTALKWH,
                            toQuantityType(total, DIGITS_KWH, Units.KILOWATT_HOUR));
                    accumulatedTotal += total;
                    totalPresent = true;
                }
                if (emeter.totalReturned != null) {
                    double totalReturned = emeter.totalReturned / 1000; // convert Wh to kWh
                    meterUpdated |= thingHandler.updateChannel(groupName, CHANNEL_EMETER_TOTALRET,
                            toQuantityType(totalReturned, DIGITS_KWH, Units.KILOWATT_HOUR));
                    accumulatedReturned += totalReturned;
                    returnedPresent = true;
                }
                if (emeter.reactive != null) {
                    meterUpdated |= thingHandler.updateChannel(groupName, CHANNEL_EMETER_REACTWATTS,
                            toQuantityType(emeter.reactive, DIGITS_VAR, Units.VAR));
                }
                if (emeter.apparentPower != null) {
                    meterUpdated |= thingHandler.updateChannel(groupName, CHANNEL_EMETER_APPARENT,
                            toQuantityType(emeter.apparentPower, DIGITS_WATT, Units.VOLT_AMPERE));
                    accumulatedApparent += emeter.apparentPower;
                    apparentPresent = true;
                }
                if (emeter.voltage != null) {
                    meterUpdated |= thingHandler.updateChannel(groupName, CHANNEL_EMETER_VOLTAGE,
                            toQuantityType(emeter.voltage, DIGITS_VOLT, Units.VOLT));
                }
                if (emeter.current != null) {
                    meterUpdated |= thingHandler.updateChannel(groupName, CHANNEL_EMETER_CURRENT,
                            toQuantityType(emeter.current, DIGITS_AMPERE, Units.AMPERE));
                }
                if (emeter.frequency != null) {
                    meterUpdated |= thingHandler.updateChannel(groupName, CHANNEL_EMETER_FREQUENCY,
                            toQuantityType(getDouble(emeter.frequency), DIGITS_FREQUENCY, Units.HERTZ));
                }
                Double pf = computePF(emeter);
                meterUpdated |= thingHandler.updateChannel(groupName, CHANNEL_EMETER_PFACTOR,
                        getDecimal(pf != null ? pf : 0.0));

                // by_minute[N] is the independent Wh sum for minute N+1 minutes ago, not a running average.
                // lastPower1 (W, deprecated) has no dual-write mapping to energyHistMin1 (Wh incompatible
                // unit), so both are written explicitly here.
                @Nullable
                Double @Nullable [] byMinute = emeter.energyByMinute;
                if (byMinute != null && byMinute.length > 0) {
                    Double minute1Wh = byMinute[0];
                    if (minute1Wh != null) {
                        thingHandler.updateChannel(groupName, CHANNEL_METER_LASTMIN1,
                                toQuantityType(minute1Wh * 60.0, DIGITS_WATT, Units.WATT));
                    }
                    Double minute2Wh = byMinute.length > 1 ? byMinute[1] : null;
                    Double minute3Wh = byMinute.length > 2 ? byMinute[2] : null;
                    meterUpdated |= writeMinuteHistoryChannels(thingHandler, groupName, minute1Wh, minute2Wh,
                            minute3Wh);
                }

                if (emeter.power != null) {
                    accumulatedWatts += emeter.power;
                }
                if (meterUpdated) {
                    thingHandler.updateChannel(groupName, CHANNEL_LAST_UPDATE, getTimestamp());
                }
                updated |= meterUpdated;
            }
            m++;
        }
        updateDeviceStatusTotals(thingHandler, status, accumulatedWatts, accumulatedTotal, totalPresent,
                accumulatedReturned, returnedPresent, accumulatedApparent, apparentPresent);
        return updated;
    }

    private static boolean updateAggregatedMeter(ShellyThingInterface thingHandler, ShellySettingsStatus status,
            ShellyDeviceProfile profile) {
        if (status.meters == null || status.meters.isEmpty()) {
            return false;
        }
        double currentWatts = 0.0;
        double totalWatts = 0.0;
        @Nullable
        Double[] lastMinutes = new @Nullable Double[3];
        long timestamp = 0L;
        String groupName = CHANNEL_GROUP_METER;
        boolean updated = false;

        if (!thingHandler.areChannelsCreated()) {
            // Create channels unconditionally — do not gate on isValid (device may still be booting)
            thingHandler.updateChannelDefinitions(ShellyChannelDefinitions.createMeterChannels(thingHandler.getThing(),
                    profile, status.meters.get(0), groupName));
        }

        boolean anyValid = false;
        for (ShellySettingsMeter meter : status.meters) {
            // RGBW2 in white mode doesn't report the valid flag correctly (same workaround as
            // updateSimpleMeters), so isLight bypasses the isValid gate
            if (getBool(meter.isValid) || profile.isLight) {
                anyValid = true;
                currentWatts += getDouble(meter.power);
                totalWatts += getDouble(meter.total);
                Double[] counters = meter.counters;
                if (counters != null) {
                    for (int i = 0; i < lastMinutes.length && i < counters.length; i++) {
                        Double counter = counters[i];
                        if (counter != null) {
                            Double sum = lastMinutes[i];
                            lastMinutes[i] = (sum != null ? sum : 0.0) + counter;
                        }
                    }
                }
                if (getLong(meter.timestamp) > timestamp) {
                    timestamp = getLong(meter.timestamp);
                }
            }
        }

        if (!anyValid) {
            return false;
        }

        updated |= updateMinuteCounters(thingHandler, groupName, lastMinutes);
        totalWatts = totalWatts / (60.0 * 1000.0); // convert Watt/Min to kWh
        updated |= thingHandler.updateChannel(groupName, CHANNEL_METER_CURRENTWATTS,
                toQuantityType(currentWatts, DIGITS_WATT, Units.WATT));
        updated |= thingHandler.updateChannel(groupName, CHANNEL_METER_TOTALKWH,
                toQuantityType(totalWatts, DIGITS_KWH, Units.KILOWATT_HOUR));
        if (updated) {
            if (timestamp > 0) {
                thingHandler.updateChannel(groupName, CHANNEL_LAST_UPDATE,
                        getTimestamp(getString(profile.settings.timezone), timestamp));
            } else {
                thingHandler.updateChannel(groupName, CHANNEL_LAST_UPDATE, getTimestamp());
            }
        }
        return updated;
    }

    private static void updateDeviceStatusTotals(ShellyThingInterface thingHandler, ShellySettingsStatus status,
            double accumulatedWatts, double accumulatedTotal, boolean totalPresent, double accumulatedReturned,
            boolean returnedPresent, double accumulatedApparent, boolean apparentPresent) {
        thingHandler.updateChannel(CHANNEL_GROUP_DEV_STATUS, CHANNEL_DEVST_ACCUWATTS, toQuantityType(
                status.totalPower != null ? status.totalPower : accumulatedWatts, DIGITS_WATT, Units.WATT));
        if (status.totalReturned != null || returnedPresent) {
            thingHandler.updateChannel(CHANNEL_GROUP_DEV_STATUS, CHANNEL_DEVST_ACCURETURNED,
                    toQuantityType(status.totalReturned != null ? status.totalReturned / 1000 : accumulatedReturned,
                            DIGITS_KWH, Units.KILOWATT_HOUR));
        }
        if (status.totalApparent != null || apparentPresent) {
            thingHandler.updateChannel(CHANNEL_GROUP_DEV_STATUS, CHANNEL_DEVST_ACCUAPPARENT,
                    toQuantityType(status.totalApparent != null ? status.totalApparent : accumulatedApparent,
                            DIGITS_WATT, Units.VOLT_AMPERE));
        }
        // device#totalEnergy: device-reported hardware total (status.totalKWH, from emdata on HTTP poll)
        // or binding-computed sum of per-meter totals when device does not report its own (Gen1, WS push).
        // status.totalKWH is reset to null at the start of fillDeviceStatus and is only set when
        // emdata arrives; WS pushes leave it null so accumulatedTotal is used. Never fall back to 0.
        if (status.totalKWH != null || totalPresent) {
            State totalEnergy = toQuantityType(status.totalKWH != null ? status.totalKWH / 1000 : accumulatedTotal,
                    DIGITS_KWH, Units.KILOWATT_HOUR);
            // Both deprecated ids forward to device#totalEnergy via the dual-write; writing them keeps
            // items linked to the pre-5.2 channels (accumulatedWTotal, device#totalKWH) working.
            thingHandler.updateChannel(CHANNEL_GROUP_DEV_STATUS, CHANNEL_DEVST_ACCUTOTAL, totalEnergy);
            thingHandler.updateChannel(CHANNEL_GROUP_DEV_STATUS, CHANNEL_DEVST_TOTALKWH, totalEnergy);
        }
    }

    /**
     * Write Gen1 counters[] (W-min, independent per-minute sums like Gen2's by_minute[]) to
     * lastPower1/energyHistMin1-3, plus their average once all three are present.
     */
    private static boolean updateMinuteCounters(ShellyThingInterface thingHandler, String groupName,
            @Nullable Double @Nullable [] counters) {
        if (counters == null || counters.length == 0 || counters[0] == null) {
            return false;
        }
        double wattMin = getDouble(counters[0]);
        Double wh1 = wattMin / 60.0;
        boolean updated = thingHandler.updateChannel(groupName, CHANNEL_METER_LASTMIN1,
                toQuantityType(wattMin, DIGITS_WATT, Units.WATT));
        Double wh2 = counters.length > 1 && counters[1] != null ? getDouble(counters[1]) / 60.0 : null;
        Double wh3 = counters.length > 2 && counters[2] != null ? getDouble(counters[2]) / 60.0 : null;
        return updated | writeMinuteHistoryChannels(thingHandler, groupName, wh1, wh2, wh3);
    }

    /**
     * Write up to 3 independent per-minute energy sums (Wh) to energyHistMin1-3, plus their
     * average to energyAvgLast3Min once all three are present. Shared by Gen1's counters[] and
     * Gen2's by_minute[] handling.
     */
    private static boolean writeMinuteHistoryChannels(ShellyThingInterface thingHandler, String groupName,
            @Nullable Double wh1, @Nullable Double wh2, @Nullable Double wh3) {
        boolean updated = false;
        if (wh1 != null) {
            updated |= thingHandler.updateChannel(groupName, CHANNEL_METER_ENERGYHISTMIN1,
                    toQuantityType(wh1, DIGITS_KWH, Units.WATT_HOUR));
        }
        if (wh2 != null) {
            updated |= thingHandler.updateChannel(groupName, CHANNEL_METER_ENERGYHISTMIN2,
                    toQuantityType(wh2, DIGITS_KWH, Units.WATT_HOUR));
        }
        if (wh3 != null) {
            updated |= thingHandler.updateChannel(groupName, CHANNEL_METER_ENERGYHISTMIN3,
                    toQuantityType(wh3, DIGITS_KWH, Units.WATT_HOUR));
        }
        if (wh1 != null && wh2 != null && wh3 != null) {
            updated |= thingHandler.updateChannel(groupName, CHANNEL_METER_ENERGYAVGLAST3MIN,
                    toQuantityType((wh1 + wh2 + wh3) / 3.0, DIGITS_KWH, Units.WATT_HOUR));
        }
        return updated;
    }

    private static @Nullable Double computePF(ShellySettingsEMeter emeter) {
        if (emeter.pf != null) { // EM3
            return emeter.pf; // take device value
        }

        // EM: compute from provided values
        if (emeter.reactive != null && emeter.power != null
                && Math.abs(emeter.power) + Math.abs(emeter.reactive) > 1.5) {
            return emeter.power / Math.sqrt(emeter.power * emeter.power + emeter.reactive * emeter.reactive);
        }
        return null;
    }

    /**
     * Update Sensor channel
     *
     * @param thingHandler Thing Handler instance
     * @param status Last ShellySettingsStatus
     *
     * @throws ShellyApiException
     */
    public static boolean updateSensors(ShellyThingInterface thingHandler, ShellySettingsStatus status)
            throws ShellyApiException {
        ShellyDeviceProfile profile = thingHandler.getProfile();

        boolean updated = false;
        if (profile.isSensor || profile.hasBattery) {
            ShellyStatusSensor sdata = thingHandler.getApi().getSensorStatus();
            if (!thingHandler.areChannelsCreated()) {
                thingHandler.updateChannelDefinitions(
                        ShellyChannelDefinitions.createSensorChannels(thingHandler.getThing(), profile, sdata));
            }

            updated |= thingHandler.updateWakeupReason(sdata.actReasons);

            if ((sdata.sensor != null) && sdata.sensor.isValid) {
                // Shelly DW: “sensor”:{“state”:“open”, “is_valid”:true},
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_STATE,
                        getOpenClosed(getString(sdata.sensor.state).equalsIgnoreCase(SHELLY_API_DWSTATE_OPEN)));
                String sensorError = sdata.sensorError;
                boolean changed = thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_ERROR,
                        getStringType(sensorError));
                if (changed && !"0".equals(sensorError)) {
                    thingHandler.postEvent(getString(sdata.sensorError), true);
                }
                updated |= changed;
            }
            if (sdata.tmp != null && getBool(sdata.tmp.isValid)) {
                Double temp = getString(sdata.tmp.units).toUpperCase(Locale.ROOT).equals(SHELLY_TEMP_CELSIUS)
                        ? getDouble(sdata.tmp.tC)
                        : getDouble(sdata.tmp.tF);
                updated |= updateTempChannel(thingHandler, CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_TEMP,
                        temp.doubleValue(), getString(sdata.tmp.units));
            } else if (status.thermostats != null) {
                // Shelly TRV
                List<ShellyThermnostat> thermostats = profile.settings.thermostats;
                if (thermostats != null) {
                    ShellyThermnostat ps = thermostats.get(0);
                    ShellyThermnostat t = status.thermostats.get(0);
                    int bminutes = getInteger(t.boostMinutes) >= 0 ? getInteger(t.boostMinutes)
                            : getInteger(ps.boostMinutes);
                    updated |= thingHandler.updateChannel(CHANNEL_GROUP_CONTROL, CHANNEL_CONTROL_BCONTROL,
                            getOnOff(getInteger(t.boostMinutes) > 0));
                    updated |= thingHandler.updateChannel(CHANNEL_GROUP_CONTROL, CHANNEL_CONTROL_BTIMER,
                            toQuantityType((double) bminutes, DIGITS_NONE, Units.MINUTE));
                    updated |= thingHandler.updateChannel(CHANNEL_GROUP_CONTROL, CHANNEL_CONTROL_MODE,
                            getStringType(getBool(t.schedule) ? SHELLY_TRV_MODE_AUTO : SHELLY_TRV_MODE_MANUAL));

                    int pid = getBool(t.schedule) ? getInteger(t.profile) : 0;
                    updated |= thingHandler.updateChannel(CHANNEL_GROUP_CONTROL, CHANNEL_CONTROL_SCHEDULE,
                            getOnOff(t.schedule));
                    updated |= thingHandler.updateChannel(CHANNEL_GROUP_CONTROL, CHANNEL_CONTROL_PROFILE,
                            getStringType(profile.getValueProfile(0, pid)));
                    if (t.tmp != null) {
                        updated |= updateTempChannel(thingHandler, CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_TEMP,
                                t.tmp.value, t.tmp.units);
                        if (t.targetTemp.unit == null) {
                            t.targetTemp.unit = t.tmp.units;
                        }
                        updated |= updateTempChannel(thingHandler, CHANNEL_GROUP_CONTROL, CHANNEL_CONTROL_SETTEMP,
                                t.targetTemp.value, t.targetTemp.unit);
                    }
                    if (t.pos != null) {
                        updated |= thingHandler.updateChannel(CHANNEL_GROUP_CONTROL, CHANNEL_CONTROL_POSITION,
                                t.pos != -1 ? toQuantityType(t.pos, DIGITS_NONE, Units.PERCENT) : UnDefType.UNDEF);
                        updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_STATE,
                                getOpenClosed(getDouble(t.pos) > 0));
                    }
                }
            }

            if (sdata.hum != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_HUM,
                        toQuantityType(getDouble(sdata.hum.value), DIGITS_PERCENT, Units.PERCENT));
            }
            if ((sdata.lux != null) && getBool(sdata.lux.isValid)) {
                // “lux”:{“value”:30, “illumination”: “dark”, “is_valid”:true},
                if (sdata.lux.value != null) {
                    updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_LUX,
                            toQuantityType(getDouble(sdata.lux.value), DIGITS_LUX, Units.LUX));
                }
                if (sdata.lux.illumination != null) {
                    updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_ILLUM,
                            getStringType(sdata.lux.illumination));
                }
            }
            if (sdata.accel != null && sdata.accel.tilt != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_TILT,
                        toQuantityType(getDouble(sdata.accel.tilt.doubleValue()), DIGITS_NONE, Units.DEGREE_ANGLE));
            }
            if (sdata.flood != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_FLOOD,
                        getOnOff(sdata.flood));
            }
            if (sdata.smoke != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_SMOKE,
                        getOnOff(sdata.smoke));
            }
            if (sdata.mute != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_MUTE, getOnOff(sdata.mute));
            }

            if (sdata.gasSensor != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_DEV_STATUS, CHANNEL_DEVST_SELFTTEST,
                        getStringType(sdata.gasSensor.selfTestState));
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_ALARM_STATE,
                        getStringType(sdata.gasSensor.alarmState));
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_SSTATE,
                        getStringType(sdata.gasSensor.sensorState));
            }
            if ((sdata.concentration != null) && sdata.concentration.isValid) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_PPM, toQuantityType(
                        getInteger(sdata.concentration.ppm).doubleValue(), DIGITS_NONE, Units.PARTS_PER_MILLION));
            }
            if ((sdata.adcs != null) && (!sdata.adcs.isEmpty())) {
                ShellyADC adc = sdata.adcs.get(0);
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_VOLTAGE,
                        toQuantityType(getDouble(adc.voltage), 2, Units.VOLT));
            }
            if (sdata.rotationX != null) {
                // BLU Remote
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_ROTATIONX,
                        toQuantityType(getDouble(sdata.rotationX.doubleValue()), DIGITS_ROTATION, Units.DEGREE_ANGLE));
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_ROTATIONY,
                        toQuantityType(getDouble(sdata.rotationY.doubleValue()), DIGITS_ROTATION, Units.DEGREE_ANGLE));
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_ROTATIONZ,
                        toQuantityType(getDouble(sdata.rotationZ.doubleValue()), DIGITS_ROTATION, Units.DEGREE_ANGLE));
            }
            if (sdata.direction != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_DIRECTION,
                        getStringType(sdata.direction));
            }
            if (sdata.steps != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_STEPS,
                        getDecimal(sdata.steps));
            }
            if (sdata.channel != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_CHANNEL,
                        getDecimal(sdata.channel));
            }
            if (sdata.distance != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_DISTANCE,
                        toQuantityType(getDouble(sdata.distance), DIGITS_DISTANCE, MetricPrefix.MILLI(SIUnits.METRE)));
            }
            if (sdata.sensor != null && sdata.sensor.vibration != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_VIBRATION,
                        OnOffType.from(sdata.sensor.vibration));
            }

            // WS90
            if (sdata.rain != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_RAINST,
                        OnOffType.from(getBool(sdata.rain)));
            }
            if (sdata.windSpeed != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_WINDSP,
                        toQuantityType(getDouble(sdata.windSpeed), DIGITS_WIND, Units.METRE_PER_SECOND));
            }
            if (sdata.windDirection != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_WINDDIR,
                        toQuantityType(getDouble(sdata.windDirection), DIGITS_NONE, Units.DEGREE_ANGLE));
            }
            if (sdata.gustSpeed != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_GUSTSP,
                        toQuantityType(getDouble(sdata.gustSpeed), DIGITS_WIND, Units.METRE_PER_SECOND));
            }
            if (sdata.pressure != null) {
                Unit<Pressure> hpa = MetricPrefix.HECTO(SIUnits.PASCAL).asType(Pressure.class);
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_PRESSURE,
                        toQuantityType(getDouble(sdata.pressure), DIGITS_PRESSURE, hpa));
            }
            if (sdata.precipitation != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_PRECIPITATION,
                        toQuantityType(getDouble(sdata.precipitation), DIGITS_PRECIPITATION,
                                MetricPrefix.MILLI(SIUnits.METRE)));
            }
            if (sdata.dewPoint != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_DEWPOINT,
                        toQuantityType(getDouble(sdata.dewPoint), DIGITS_TEMP, SIUnits.CELSIUS));
            }
            if (sdata.uvIndex != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_UV,
                        getDecimal(sdata.uvIndex, DIGITS_UV));
            }

            boolean charger = (getInteger(profile.settings.externalPower) == 1) || getBool(sdata.charger);
            if ((profile.settings.externalPower != null) || (sdata.charger != null)) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_DEV_STATUS, CHANNEL_DEVST_CHARGER,
                        getOnOff(charger));
            }
            if (sdata.bat != null) { // no update for Sense
                if (sdata.bat.value != null) {
                    updated |= thingHandler.updateChannel(CHANNEL_GROUP_BATTERY, CHANNEL_SENSOR_BAT_LEVEL,
                            toQuantityType(getDouble(sdata.bat.value), 0, Units.PERCENT));
                }

                int lowBattery = thingHandler.getThingConfig().getLowBattery();
                Boolean batteryLowFlag = sdata.bat.batteryLow;
                boolean isLow = batteryLowFlag != null ? batteryLowFlag.booleanValue()
                        : (sdata.bat.value != null && !charger && getDouble(sdata.bat.value) < lowBattery);
                boolean changed = thingHandler.updateChannel(CHANNEL_GROUP_BATTERY, CHANNEL_SENSOR_BAT_LOW,
                        getOnOff(isLow));
                updated |= changed;
                if (changed && isLow) {
                    thingHandler.postEvent(ALARM_TYPE_LOW_BATTERY, false);
                }
            }

            if (sdata.motion != null) { // Shelly Sense
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_MOTION,
                        getOnOff(sdata.motion));
            }
            if (sdata.sensor != null) { // Shelly Motion
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_MOTION_ACT,
                        getOnOff(sdata.sensor.motionActive));
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_MOTION,
                        getOnOff(sdata.sensor.motion));
                long timestamp = getLong(sdata.sensor.motionTimestamp);
                if (timestamp != 0) {
                    updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_SENSOR_MOTION_TS,
                            getTimestamp(getString(profile.settings.timezone), timestamp));
                }
            }

            updated |= thingHandler.updateInputs(status);

            if (updated) {
                thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_LAST_UPDATE, getTimestamp());
            }
        }

        // Update Add-On channels (Shelly 1/1PM and Plus 1/1PM with sensor addon)
        boolean hasAddon = hasAddon(status);
        ShellyExtTemperature extTemperature = status.extTemperature;
        if (extTemperature != null) {
            // Shelly 1/1PM support up to 3 external sensors
            // for whatever reason those are not represented as an array, but 3 elements
            updated |= updateTempChannel(extTemperature.sensor1, thingHandler, CHANNEL_ESENSOR_TEMP1);
            updated |= updateTempChannel(extTemperature.sensor2, thingHandler, CHANNEL_ESENSOR_TEMP2);
            updated |= updateTempChannel(extTemperature.sensor3, thingHandler, CHANNEL_ESENSOR_TEMP3);
            updated |= updateTempChannel(extTemperature.sensor4, thingHandler, CHANNEL_ESENSOR_TEMP4);
            updated |= updateTempChannel(extTemperature.sensor5, thingHandler, CHANNEL_ESENSOR_TEMP5);
        }
        ShellyExtHumidity extHumidity = status.extHumidity;
        if (extHumidity != null) {
            ShellyShortHum humSensor = extHumidity.sensor1;
            if (humSensor != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_ESENSOR_HUMIDITY,
                        toQuantityType(getDouble(humSensor.hum), DIGITS_PERCENT, Units.PERCENT));
            }
        }
        ShellyExtVoltage extVoltage = status.extVoltage;
        if (extVoltage != null) {
            ShellyShortVoltage voltSensor = extVoltage.sensor1;
            if (voltSensor != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_ESENSOR_VOLTAGE,
                        toQuantityType(getDouble(voltSensor.voltage), 4, Units.VOLT));
            }
        }
        ShellyExtDigitalInput extDigitalInput = status.extDigitalInput;
        if (extDigitalInput != null) {
            ShellyShortDigitalInput digSensor = extDigitalInput.sensor1;
            if (digSensor != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_ESENSOR_DIGITALINPUT,
                        getOnOff(digSensor.state));
            }
        }
        ShellyExtAnalogInput extAnalogInput = status.extAnalogInput;
        if (extAnalogInput != null) {
            ShellyShortAnalogInput anaSensor = extAnalogInput.sensor1;
            if (anaSensor != null) {
                updated |= thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_ESENSOR_ANALOGINPUT,
                        toQuantityType(getDouble(anaSensor.percent), DIGITS_PERCENT, Units.PERCENT));
            }
        }
        if (hasAddon && !(profile.isSensor || profile.hasBattery)) {
            // Relay devices with addon sensors: always refresh lastUpdate so the channel shows
            // when sensor data was last received, even when temperature values are unchanged
            thingHandler.updateChannel(CHANNEL_GROUP_SENSOR, CHANNEL_LAST_UPDATE, getTimestamp());
            updated = true;
        }

        return updated;
    }

    public static boolean updateRGBW(ShellyThingInterface thingHandler, ShellySettingsStatus orgStatus)
            throws ShellyApiException {
        boolean updated = false;
        ShellyDeviceProfile profile = thingHandler.getProfile();
        if (profile.isRGBW2) {
            if (!thingHandler.areChannelsCreated()) {
                return false;
            }
            ShellySettingsLight light = orgStatus.lights.get(0);
            ShellyColorUtils col = new ShellyColorUtils();
            col.setRGBW(light.red, light.green, light.blue, light.white);
            updated |= thingHandler.updateChannel(CHANNEL_GROUP_COLOR_CONTROL, CHANNEL_COLOR_RED, col.percentRed);
            updated |= thingHandler.updateChannel(CHANNEL_GROUP_COLOR_CONTROL, CHANNEL_COLOR_GREEN, col.percentGreen);
            updated |= thingHandler.updateChannel(CHANNEL_GROUP_COLOR_CONTROL, CHANNEL_COLOR_BLUE, col.percentBlue);
            updated |= thingHandler.updateChannel(CHANNEL_GROUP_COLOR_CONTROL, CHANNEL_COLOR_WHITE, col.percentWhite);
            updated |= thingHandler.updateChannel(CHANNEL_GROUP_COLOR_CONTROL, CHANNEL_COLOR_PICKER, col.toHSB());

        }
        return updated;
    }

    public static boolean updateDimmers(ShellyThingInterface thingHandler, ShellySettingsStatus orgStatus)
            throws ShellyApiException {
        boolean updated = false;
        ShellyDeviceProfile profile = thingHandler.getProfile();
        if (profile.isDimmer) {
            // We need to fixup the returned Json: The dimmer returns light[] element, which is ok, but it doesn't have
            // the same structure as lights[] from Bulb,RGBW2 and Duo. The tag gets replaced by dimmers[] so that Gson
            // maps to a different structure (ShellyShortLight).
            Gson gson = new Gson();
            ShellySettingsStatus dstatus = !profile.isGen2
                    ? fromJson(gson, Shelly1ApiJsonDTO.fixDimmerJson(orgStatus.json), ShellySettingsStatus.class)
                    : orgStatus;

            int l = 0;
            for (ShellyShortLightStatus dimmer : dstatus.dimmers) {
                String groupName = profile.getControlGroup(l);

                if (!thingHandler.areChannelsCreated()) {
                    thingHandler.updateChannelDefinitions(ShellyChannelDefinitions
                            .createDimmerChannels(thingHandler.getThing(), profile, dstatus, l));
                }

                List<ShellySettingsDimmer> dimmers = profile.settings.dimmers;
                if (dimmers != null) {
                    ShellySettingsDimmer ds = dimmers.get(l);
                    if (ds.name != null) {
                        updated |= thingHandler.updateChannel(groupName, CHANNEL_OUTPUT_NAME, getStringType(ds.name));
                    }
                }

                // On a status update we map a dimmer.ison = false to brightness 0 rather than the device's brightness
                // and send an OFF status to the same channel.
                // When the device's brightness is > 0 we send the new value to the channel and an ON command
                if (dimmer.ison != null) {
                    if (dimmer.ison) {
                        updated |= thingHandler.updateChannel(groupName, CHANNEL_BRIGHTNESS + "$Switch", OnOffType.ON);
                        updated |= thingHandler.updateChannel(groupName, CHANNEL_BRIGHTNESS + "$Value",
                                toQuantityType((double) getInteger(dimmer.brightness), DIGITS_NONE, Units.PERCENT));
                    } else {
                        updated |= thingHandler.updateChannel(groupName, CHANNEL_BRIGHTNESS + "$Switch", OnOffType.OFF);
                        updated |= thingHandler.updateChannel(groupName, CHANNEL_BRIGHTNESS + "$Value",
                                toQuantityType(0.0, DIGITS_NONE, Units.PERCENT));
                    }
                }
                if (dimmer.hasTimer != null) {
                    updated |= thingHandler.updateChannel(groupName, CHANNEL_TIMER_ACTIVE, getOnOff(dimmer.hasTimer));
                }

                if (dimmers != null) {
                    ShellySettingsDimmer dsettings = dimmers.get(l);
                    updated |= thingHandler.updateChannel(groupName, CHANNEL_TIMER_AUTOON,
                            toQuantityType(getDouble(dsettings.autoOn), Units.SECOND));
                    updated |= thingHandler.updateChannel(groupName, CHANNEL_TIMER_AUTOOFF,
                            toQuantityType(getDouble(dsettings.autoOff), Units.SECOND));
                }

                l++;
            }
        }
        return updated;
    }

    public static boolean hasAddon(ShellySettingsStatus status) {
        return status.extTemperature != null || status.extHumidity != null || status.extVoltage != null
                || status.extDigitalInput != null || status.extAnalogInput != null;
    }

    public static boolean updateTempChannel(@Nullable ShellyShortTemp sensor, ShellyThingInterface thingHandler,
            String channel) {
        if (sensor == null) {
            return false;
        }
        return updateTempChannel(thingHandler, CHANNEL_GROUP_SENSOR, channel, sensor.tC, "");
    }

    public static boolean updateTempChannel(ShellyThingInterface thingHandler, String group, String channel,
            @Nullable Double temp, @Nullable String unit) {
        if (temp == null) {
            return false;
        }
        if (temp == SHELLY_API_INVTEMP) {
            // Sensor present but reading invalid (e.g. disconnected wire): publish UNDEF so that
            // the cache does not block the next valid reading when the sensor recovers.
            return thingHandler.updateChannel(group, channel, UnDefType.UNDEF);
        }
        return thingHandler.updateChannel(group, channel,
                toQuantityType(convertToC(temp, unit), DIGITS_TEMP, SIUnits.CELSIUS));
    }

    private static Double convertToC(@Nullable Double temp, @Nullable String unit) {
        if (temp == null || temp == SHELLY_API_INVTEMP) {
            return SHELLY_API_INVTEMP;
        }
        if (SHELLY_TEMP_FAHRENHEIT.equalsIgnoreCase(getString(unit))) {
            // convert Fahrenheit to Celsius
            return ImperialUnits.FAHRENHEIT.getConverterTo(SIUnits.CELSIUS).convert(temp).doubleValue();
        }
        return temp;
    }
}
