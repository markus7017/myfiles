/*
 * Copyright (c) 2010-2026 Contributors to the openHAB project
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0
 *
 * SPDX-License-Identifier: EPL-2.0
 */
package org.openhab.binding.shelly.internal.handler;

import org.eclipse.jdt.annotation.NonNullByDefault;
import org.eclipse.jetty.client.HttpClient;
import org.eclipse.jetty.websocket.client.WebSocketClient;
import org.openhab.binding.shelly.internal.api1.Shelly1CoapServer;
import org.openhab.binding.shelly.internal.config.ShellyBindingRuntimeConfig;
import org.openhab.binding.shelly.internal.provider.ShellyTranslationProvider;
import org.openhab.core.thing.Thing;

/**
 * The {@link ShellyProtectedHandler} implements a dummy handler for password protected devices.
 *
 * @author Markus Michels - Initial contribution
 */
@NonNullByDefault
public class ShellyProtectedHandler extends ShellyBaseHandler {
    /**
     * Constructor
     *
     * @param thing The thing passed by the HandlerFactory
     * @param translationProvider
     * @param bindingConfig configuration of the binding
     * @param thingTable
     * @param coapService coap server instance
     * @param httpClient to connect to the openHAB HTTP API
     */
    public ShellyProtectedHandler(final Thing thing, final ShellyTranslationProvider translationProvider,
            final ShellyBindingRuntimeConfig bindingConfig, ShellyThingTable thingTable,
            final Shelly1CoapServer coapService, final HttpClient httpClient, WebSocketClient webSocketClient) {
        super(thing, translationProvider, bindingConfig, thingTable, coapService, httpClient, webSocketClient);
    }

    @Override
    public void initialize() {
        super.initialize();
    }
}
