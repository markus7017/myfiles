/*
 * Copyright (c) 2010-2026 Contributors to the openHAB project
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0
 *
 * SPDX-License-Identifier: EPL-2.0
 */
package org.openhab.binding.shelly.internal.discovery;

import static org.openhab.binding.shelly.internal.ShellyBindingConstants.BINDING_ID;
import static org.openhab.binding.shelly.internal.ShellyDevices.SUPPORTED_THING_TYPES;
import static org.openhab.binding.shelly.internal.util.ShellyUtils.*;

import java.io.IOException;
import java.net.Inet4Address;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

import javax.jmdns.ServiceInfo;

import org.eclipse.jdt.annotation.NonNullByDefault;
import org.eclipse.jdt.annotation.Nullable;
import org.eclipse.jetty.client.HttpClient;
import org.openhab.binding.shelly.internal.api.ShellyDeviceProfile;
import org.openhab.binding.shelly.internal.config.ShellyBindingConfiguration;
import org.openhab.binding.shelly.internal.config.ShellyBindingRuntimeConfig;
import org.openhab.binding.shelly.internal.handler.ShellyThingTable;
import org.openhab.binding.shelly.internal.provider.ShellyTranslationProvider;
import org.openhab.core.config.discovery.DiscoveryResult;
import org.openhab.core.config.discovery.mdns.MDNSDiscoveryParticipant;
import org.openhab.core.i18n.LocaleProvider;
import org.openhab.core.io.net.http.HttpClientFactory;
import org.openhab.core.net.NetworkAddressService;
import org.openhab.core.thing.ThingTypeUID;
import org.openhab.core.thing.ThingUID;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class identifies Shelly devices by their mDNS service information.
 *
 * On discovery result
 * - Extract IPv4 address from ServiceInfo.getInet4Addresses()
 * - Read the gen TXT record ("2", "3", "4" → Gen2) and fall back to
 * ShellyDeviceProfile.isGeneration2(serviceName) for older firmware that
 * does not publish the property
 * - Capture a local snapshot of this.bindingConfig (volatile field) to avoid a
 * TOCTOU race with concurrent @Modified callbacks
 * - Probe the device via HTTP to read /shelly or /settings and confirm its type
 * - Call ShellyThingCreator.getThingUID() to map the device type string to a ThingTypeUID
 * - Build and return a DiscoveryResult with the device's IP as deviceIp property
 *
 * @author Markus Michels - Initial contribution
 */
@NonNullByDefault
@Component(service = MDNSDiscoveryParticipant.class)
public class ShellyMDNSDiscoveryParticipant implements MDNSDiscoveryParticipant {

    /**
     * For backwards compatibility with older Gen 1 devices and Gen 2 devices
     * with older firmware versions, <code>_http._tcp.local.</code> is used.
     * Newer firmware versions and Gen2+ devices advertise themselves as
     * <code>_shelly._tcp.local.</code> as well.
     */
    private static final String SERVICE_TYPE = "_http._tcp.local.";

    private final Logger logger = LoggerFactory.getLogger(ShellyMDNSDiscoveryParticipant.class);
    private final ShellyBindingRuntimeConfig bindingConfig;
    private final NetworkAddressService networkAddressService;
    private final ShellyTranslationProvider messages;
    private final ShellyThingTable thingTable;
    private final HttpClient httpClient;
    private final ConfigurationAdmin configurationAdmin;

    public static final Pattern SHELLY_SERVICE_NAME_PATTERN = Pattern
            .compile("^([a-z0-9]*shelly[a-z0-9]*)-([a-z0-9]+)$", Pattern.CASE_INSENSITIVE);

    public static boolean isValidShellyServiceName(String serviceName) {
        return SHELLY_SERVICE_NAME_PATTERN.matcher(serviceName).matches();
    }

    @Activate
    public ShellyMDNSDiscoveryParticipant(@Reference ConfigurationAdmin configurationAdmin,
            @Reference HttpClientFactory httpClientFactory, @Reference LocaleProvider localeProvider,
            @Reference ShellyTranslationProvider translationProvider, @Reference ShellyThingTable thingTable,
            @Reference NetworkAddressService networkAddressService, ComponentContext componentContext) {
        logger.debug("Activating Shelly mDNS discovery service");
        this.configurationAdmin = configurationAdmin;
        this.messages = translationProvider;
        this.httpClient = httpClientFactory.getCommonHttpClient();
        this.thingTable = thingTable;
        this.networkAddressService = networkAddressService;

        ShellyBindingConfiguration rawConfig = ShellyBindingConfiguration
                .fromProperties(componentContext.getProperties());
        bindingConfig = new ShellyBindingRuntimeConfig(rawConfig, -1, networkAddressService);
    }

    @Override
    public Set<ThingTypeUID> getSupportedThingTypeUIDs() {
        return SUPPORTED_THING_TYPES;
    }

    @Override
    public String getServiceType() {
        return SERVICE_TYPE;
    }

    /**
     * Process updates to Binding Config
     *
     * @param componentContext
     */
    @Modified
    protected void modified(final ComponentContext componentContext) {
        logger.debug("Shelly Binding Configuration refreshed");
        ShellyBindingConfiguration rawConfig = ShellyBindingConfiguration
                .fromProperties(componentContext.getProperties());
        bindingConfig.update(rawConfig, networkAddressService);
    }

    @Override
    public @Nullable DiscoveryResult createResult(final ServiceInfo service) {
        // Shelly Duo: Name starts with "Shelly" rather than "shelly"
        String serviceName = service.getName().toLowerCase(Locale.ROOT);
        if (!isValidShellyServiceName(serviceName)) {
            return null;
        }

        String address = "";
        Inet4Address[] hostAddresses = service.getInet4Addresses();
        if ((hostAddresses != null) && (hostAddresses.length > 0)) {
            address = substringAfter(hostAddresses[0].toString(), "/");
        }
        if (address.isEmpty()) {
            logger.trace("{}: Shelly device discovered with empty IP address (service-name={})", serviceName, service);
            return null;
        }
        logger.debug("{}: Shelly device discovered: IP address={}", serviceName, address);

        try {
            // Get device settings — capture a consistent local snapshot; @Modified may run concurrently
            ShellyBindingRuntimeConfig cfg = this.bindingConfig;
            Configuration serviceConfig = configurationAdmin.getConfiguration("binding." + BINDING_ID);
            if (serviceConfig.getProperties() != null) {
                ShellyBindingConfiguration rawConfig = ShellyBindingConfiguration
                        .fromProperties(serviceConfig.getProperties());
                cfg = new ShellyBindingRuntimeConfig(rawConfig, -1, networkAddressService);
            }

            String gen = getString(service.getPropertyString("gen"));
            boolean gen2 = "2".equals(gen) || "3".equals(gen) || "4".equals(gen)
                    || ShellyDeviceProfile.isGeneration2(serviceName);
            return ShellyBasicDiscoveryService.createResult(gen2, serviceName, address, cfg, httpClient, messages,
                    thingTable);
        } catch (IOException e) {
            logger.debug("{}: Exception on processing serviceInfo '{}'", serviceName, service.getNiceTextString(), e);
            return null;
        }
    }

    @Override
    public @Nullable ThingUID getThingUID(ServiceInfo service) {
        logger.trace("ServiceInfo {}", service);
        String serviceName = service.getName();
        if (serviceName == null) {
            return null;
        }
        if (!isValidShellyServiceName(serviceName)) {
            logger.debug("{} is not a valid Shelly service name", serviceName);
            return null;
        }
        return ShellyThingCreator.getThingUID(serviceName);
    }
}
